"""NeuroCongest training/evaluation harness: numpy PPO + NS-3 episode runner."""
import os, subprocess, json, time, math
import numpy as np
from concurrent.futures import ThreadPoolExecutor

NS3 = "/home/claude/ns3dev"
EXE = f"{NS3}/build/contrib/nr/examples/ns3.46-neurocongest-exp-optimized"
WORK = "/home/claude/nc/work"
os.makedirs(WORK, exist_ok=True)
K = 5
IN_DIM = {"ppo": 5, "nc_full": 13, "nc_notasi": 13, "nc_nodrtd": 10, "nc_noamabcs": 12}


# ------------------------------------------------------------------ MLP with manual backprop
class MLP:
    def __init__(self, dims, act="tanh", seed=0, out_scale=0.01):
        rng = np.random.default_rng(seed)
        self.dims = list(dims)
        self.act = act
        self.W, self.b = [], []
        for i in range(len(dims) - 1):
            sc = out_scale if i == len(dims) - 2 else math.sqrt(2.0 / dims[i])
            self.W.append(rng.standard_normal((dims[i + 1], dims[i])) * sc)
            self.b.append(np.zeros(dims[i + 1]))

    def f(self, x):
        return np.tanh(x) if self.act == "tanh" else np.maximum(0, x)

    def df(self, y):  # derivative given activation output
        return 1 - y * y if self.act == "tanh" else (y > 0).astype(float)

    def forward(self, X, cache=False):
        hs = [X]
        h = X
        for l in range(len(self.W)):
            z = h @ self.W[l].T + self.b[l]
            h = self.f(z) if l < len(self.W) - 1 else z
            hs.append(h)
        return (h, hs) if cache else h

    def backward(self, hs, dout):
        gW, gb = [None] * len(self.W), [None] * len(self.W)
        d = dout
        for l in range(len(self.W) - 1, -1, -1):
            gW[l] = d.T @ hs[l]
            gb[l] = d.sum(0)
            if l > 0:
                d = (d @ self.W[l]) * self.df(hs[l])
        return gW, gb

    def save(self, path):
        with open(path, "w") as fh:
            fh.write(f"{len(self.W)}\n" + " ".join(map(str, self.dims)) + "\n")
            for W, b in zip(self.W, self.b):
                fh.write(" ".join(f"{x:.9g}" for x in W.ravel()) + "\n")
                fh.write(" ".join(f"{x:.9g}" for x in b.ravel()) + "\n")

    def params(self):
        return self.W + self.b

    def load(self, path):
        L = open(path).read().split("\n")
        n = int(L[0]); self.dims = [int(x) for x in L[1].split()]
        self.W, self.b = [], []
        for l in range(n):
            self.W.append(np.array([float(x) for x in L[2 + 2 * l].split()]).reshape(self.dims[l + 1], self.dims[l]))
            self.b.append(np.array([float(x) for x in L[3 + 2 * l].split()]))

    def set_params(self, ps):
        n = len(self.W)
        self.W, self.b = [p.copy() for p in ps[:n]], [p.copy() for p in ps[n:]]


class Adam:
    def __init__(self, params, lr=3e-4):
        self.lr = lr
        self.m = [np.zeros_like(p) for p in params]
        self.v = [np.zeros_like(p) for p in params]
        self.t = 0

    def step(self, params, grads):
        self.t += 1
        for i, (p, g) in enumerate(zip(params, grads)):
            self.m[i] = 0.9 * self.m[i] + 0.1 * g
            self.v[i] = 0.999 * self.v[i] + 0.001 * g * g
            mh = self.m[i] / (1 - 0.9 ** self.t)
            vh = self.v[i] / (1 - 0.999 ** self.t)
            p -= self.lr * mh / (np.sqrt(vh) + 1e-8)


def softmax(z):
    z = z - z.max(1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(1, keepdims=True)


# ------------------------------------------------------------------ NS-3 episode runner
def run_ns3(variant, seed, tag, policy=None, imprint=None, chan=None, traj=None, stochastic=False,
            sim=16.0, ues=4, extra=None):
    out = f"{WORK}/{tag}"
    cmd = [EXE, f"--variant={variant}", f"--seed={seed}", f"--out={out}", f"--simTime={sim}", f"--ueNum={ues}"]
    if policy: cmd.append(f"--policy={policy}")
    if imprint: cmd.append(f"--imprint={imprint}")
    if chan: cmd.append(f"--chan={chan}")
    if traj: cmd.append(f"--traj={traj}")
    if stochastic: cmd.append("--stochastic=1")
    if extra: cmd += extra
    t0 = time.time()
    if os.path.exists(out + "_summary.txt") and os.environ.get("NC_REUSE"):
        return out + "_summary.txt", 0.0
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        open(f"{WORK}/FAILED.log", "a").write(f"rc={r.returncode} {' '.join(cmd)}\n")
        return None, time.time() - t0
    return out + "_summary.txt", time.time() - t0


def run_many(jobs, workers=2):
    with ThreadPoolExecutor(workers) as ex:
        return list(ex.map(lambda j: run_ns3(**j), jobs))


# ------------------------------------------------------------------ summary parsing / metrics
def parse_summary(path, win_pre=1.0, frac=0.9):
    d = {"ue": {}, "bins": {}, "ho": {}}
    for line in open(path):
        p = line.split()
        if not p:
            continue
        if p[0] == "pdr":
            d["pdr"] = float(p[1])
        elif p[0] == "ue":
            u = int(p[1])
            d["ue"][u] = dict(thr=float(p[3]), rtt=float(p[5]), cv=float(p[7]))
            d["ho"][u] = [float(x) for x in p[9:]]
        elif p[0] == "bins":
            d["bins"][int(p[1])] = np.array([float(x) for x in p[2:]]) * 8 / 0.1 / 1e6  # Mbps per 100ms bin
    return d


def recovery_times(d, max_rec=3.0):
    """Handover recovery time: seconds after HO end until goodput (smoothed over 3 bins) is back to
    >= 90% of the mean goodput in the 1 s before the handover. Right-censored at max_rec."""
    out = []
    for u, hos in d["ho"].items():
        b = d["bins"].get(u)
        if b is None:
            continue
        for t in hos:
            i = int(t * 10)
            pre = b[max(0, i - 12):max(1, i - 2)]
            if len(pre) < 3 or pre.mean() < 1.0:
                continue
            target = 0.9 * pre.mean()
            rec = max_rec
            for j in range(i, min(len(b) - 2, i + int(max_rec * 10))):
                if b[j:j + 3].mean() >= target:
                    rec = (j - i) * 0.1
                    break
            out.append(rec)
    return out


def run_metrics(path):
    d = parse_summary(path)
    ue = d["ue"]
    thr = np.mean([v["thr"] for v in ue.values()])
    rtt = np.mean([v["rtt"] for v in ue.values() if v["rtt"] > 0])
    cv = np.mean([v["cv"] for v in ue.values()])
    rec = recovery_times(d)
    return dict(thr=thr, rtt=rtt, pdr=d["pdr"], cv=cv, rec=float(np.mean(rec)) if rec else float("nan"),
                n_ho=len(rec))


# ------------------------------------------------------------------ PPO
def load_traj(path, dim):
    rows = [l.split() for l in open(path) if l.strip()]
    if not rows:
        return None
    A = np.array(rows, dtype=float)
    return A  # cols: ue t cell act logp reward done state...


def gae(rew, val, last_val, gamma=0.99, lam=0.95):
    n = len(rew)
    adv = np.zeros(n)
    g = 0.0
    for t in range(n - 1, -1, -1):
        nv = val[t + 1] if t + 1 < n else last_val
        delta = rew[t] + gamma * nv - val[t]
        g = delta + gamma * lam * g
        adv[t] = g
    return adv, adv + val


class Ppo:
    def __init__(self, variant, seed=0, hidden=64, lr=3e-4):
        d = IN_DIM[variant]
        self.variant = variant
        self.actor = MLP([d, hidden, hidden, K], "tanh", seed, out_scale=0.01)
        self.actor.b[-1][2] = 1.0  # start biased toward "hold"
        self.critic = MLP([d, hidden, hidden, 1], "tanh", seed + 1, out_scale=1.0)
        self.optA = Adam(self.actor.params(), lr)
        self.optC = Adam(self.critic.params(), lr)

    def update(self, trajs, epochs=4, mb=512, clip=0.2, ent=0.01, c1=0.5, gamma=0.99, lam=0.95,
               only_last=False, fit_critic=True):
        S, A, LP, ADV, RET = [], [], [], [], []
        for T in trajs:
            for u in np.unique(T[:, 0]):
                X = T[T[:, 0] == u]
                if len(X) < 5:
                    continue
                s = X[:, 7:]
                v = self.critic.forward(s)[:, 0]
                adv, ret = gae(X[:, 5], v, v[-1], gamma, lam)
                S.append(s); A.append(X[:, 3].astype(int)); LP.append(X[:, 4]); ADV.append(adv); RET.append(ret)
        S = np.vstack(S); A = np.concatenate(A); LP = np.concatenate(LP)
        ADV = np.concatenate(ADV); RET = np.concatenate(RET)
        ADV = (ADV - ADV.mean()) / (ADV.std() + 1e-8)
        n = len(S)
        stats = {}
        for ep in range(epochs):
            idx = np.random.permutation(n)
            for i in range(0, n, mb):
                b = idx[i:i + mb]
                s, a, lp0, adv, ret = S[b], A[b], LP[b], ADV[b], RET[b]
                logits, hs = self.actor.forward(s, cache=True)
                p = softmax(logits)
                lp = np.log(p[np.arange(len(b)), a] + 1e-9)
                ratio = np.exp(lp - lp0)
                clipped = (ratio > 1 + clip) & (adv > 0) | (ratio < 1 - clip) & (adv < 0)
                g_lp = np.where(clipped, 0.0, -adv * ratio)  # d(-loss)/d lp
                onehot = np.zeros_like(p); onehot[np.arange(len(b)), a] = 1
                dlogits = (g_lp[:, None] * (onehot - p)) / len(b)
                H = -(p * np.log(p + 1e-9)).sum(1)
                dH = -p * (np.log(p + 1e-9) + H[:, None])  # dH/dlogits (per sample)
                dlogits += -ent * dH / len(b)
                gW, gb = self.actor.backward(hs, dlogits)
                if only_last:
                    for l in range(len(gW) - 1):
                        gW[l] = np.zeros_like(gW[l]); gb[l] = np.zeros_like(gb[l])
                self.optA.step(self.actor.params(), gW + gb)
                if not fit_critic:
                    continue
                v, hc = self.critic.forward(s, cache=True)
                dv = c1 * 2 * (v[:, 0] - ret)[:, None] / len(b)
                gW, gb = self.critic.backward(hc, dv)
                self.optC.step(self.critic.params(), gW + gb)
        stats["ent"] = float(H.mean())
        stats["n"] = int(n)
        return stats
