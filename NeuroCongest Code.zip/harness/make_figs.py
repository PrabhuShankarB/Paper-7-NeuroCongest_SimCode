import sys, json, re
sys.path.insert(0, "/home/claude/nc")
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from nc_lib import *
plt.rcParams.update({"font.family": "Liberation Serif", "font.size": 9, "axes.linewidth": 0.7,
                     "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
                     "legend.fontsize": 8, "figure.dpi": 300, "savefig.dpi": 300, "hatch.linewidth": 0.6})
OUT = "/home/claude/wr/figs"
SEEDS = range(201, 221)
R = json.load(open(f"{WORK}/results.json"))
PV = R["per_variant"]
def path(v, s):
    pat = {"ppo": "ev_ppo", "nc_full": "ev_nc_full", "nc_notasi": "ev_nc_notasi", "nc_nodrtd": "ev_nc_nodrtd", "nc_noamabcs": "ev_nc_noamabcs"}
    return f"{WORK}/{pat.get(v, 'cl_' + v)}_{s}_summary.txt"
NAMES = {"newreno": "NewReno", "cubic": "CUBIC", "bbr": "BBR", "westwood": "Westwood+", "ppo": "PPO (plain)", "nc_full": "NeuroCongest",
         "nc_notasi": "NC w/o TASI", "nc_nodrtd": "NC w/o DRTD-CD", "nc_noamabcs": "NC w/o AMABCS", "vegas": "Vegas", "illinois": "Illinois",
         "yeah": "YeAH", "highspeed": "HighSpeed", "veno": "Veno", "htcp": "H-TCP", "bic": "BIC", "hybla": "Hybla"}

# ---- Fig 3: event-aligned normalised goodput around handover
def aligned(v):
    acc = []
    for s in SEEDS:
        d = parse_summary(path(v, s))
        for u, hos in d["ho"].items():
            b = d["bins"].get(u)
            if b is None: continue
            for t in hos:
                i = int(t * 10)
                pre = b[max(0, i - 12):max(1, i - 2)]
                if len(pre) < 3 or pre.mean() < 1.0 or i - 10 < 0 or i + 30 > len(b): continue
                acc.append(b[i - 10:i + 30] / pre.mean())
    return np.array(acc)
fig, ax = plt.subplots(figsize=(6.5, 2.9))
sty = {"newreno": ("k", ":", None), "cubic": ("0.35", "--", None), "bbr": ("0.55", "-.", None), "ppo": ("k", "--", "s"), "nc_full": ("k", "-", "o")}
t = np.arange(-10, 30) / 10.0
for v, (c, ls, mk) in sty.items():
    A = aligned(v)
    ax.plot(t, A.mean(0), color=c, ls=ls, marker=mk, ms=2.8, markevery=3, lw=1.2, label=f"{NAMES[v]} (n={len(A)})")
ax.axvline(0, color="k", lw=0.6); ax.axhline(0.9, color="0.6", lw=0.6, ls=(0, (1, 2)))
ax.set_xlabel("Time relative to handover completion (s)"); ax.set_ylabel("Goodput / pre-handover mean")
ax.set_ylim(0, 1.5); ax.legend(ncol=3, loc="upper center", bbox_to_anchor=(0.5, -0.28))
fig.tight_layout(); fig.savefig(f"{OUT}/fig3_handover_trace.png", bbox_inches="tight"); plt.close(fig)

# ---- Fig 4: RTT-throughput operating points
fig, ax = plt.subplots(figsize=(6.5, 3.2))
mk = ["o", "s", "^", "v", "D", "P", "X", "*", "<", ">", "h", "p", "8", "d", "H", "|", "_"]
order = ["newreno", "cubic", "bbr", "westwood", "vegas", "illinois", "yeah", "highspeed", "veno", "htcp", "bic", "hybla", "ppo", "nc_full"]
for k, v in enumerate(order):
    x = PV[v]["rtt"]["mean"]; y = PV[v]["thr"]["mean"]
    if v == "nc_full":
        ax.scatter(x, y, s=70, marker="*", c="k", zorder=5, label=NAMES[v])
    elif v == "ppo":
        ax.scatter(x, y, s=38, marker="D", facecolors="none", edgecolors="k", lw=1.2, zorder=4, label=NAMES[v])
    else:
        ax.scatter(x, y, s=30, marker=mk[k % len(mk)], c="0.45", edgecolors="k", lw=0.5, label=NAMES[v])
ax.set_xlabel("Mean RTT (ms)"); ax.set_ylabel("Mean goodput per UE (Mbps)")
ax.legend(ncol=1, loc="center left", bbox_to_anchor=(1.01, 0.5))
fig.tight_layout(); fig.savefig(f"{OUT}/fig4_operating_points.png", bbox_inches="tight"); plt.close(fig)

# ---- Fig 5: paired differences forest (NC - baseline)
PD = R["paired_vs_nc_full"]
bl = ["newreno", "cubic", "bbr", "westwood", "vegas", "illinois", "yeah", "highspeed", "veno", "htcp", "bic", "hybla", "ppo"]
fig, axs = plt.subplots(1, 3, figsize=(6.5, 3.6), sharey=True)
for ax, (k, lab) in zip(axs, [("rtt", "RTT difference (ms)"), ("pdr", "PDR difference (points)"), ("rec", "Recovery-time difference (s)")]):
    for j, v in enumerate(bl):
        e = PD[v][k]
        ax.errorbar(e["diff"], j, xerr=[[e["diff"] - e["lo"]], [e["hi"] - e["diff"]]], fmt="o", color="k", ms=3.2, lw=0.9, capsize=1.8,
                    mfc="k" if (e["lo"] > 0 or e["hi"] < 0) else "white")
    ax.axvline(0, color="k", lw=0.6); ax.set_xlabel(lab, fontsize=8)
    ax.set_yticks(range(len(bl))); ax.set_yticklabels([NAMES[v] for v in bl]); ax.invert_yaxis()
fig.tight_layout(); fig.savefig(f"{OUT}/fig5_paired_forest.png", bbox_inches="tight"); plt.close(fig)

# ---- Fig 6: ablation
fig, axs = plt.subplots(1, 3, figsize=(6.5, 2.7))
vs = ["ppo", "nc_full", "nc_notasi", "nc_nodrtd", "nc_noamabcs"]
short = ["PPO", "NC", "NC−T", "NC−D", "NC−A"]
hat = [None, "///", "\\\\\\", "xxx", "..."]
for ax, (k, lab) in zip(axs, [("rtt", "Mean RTT (ms)"), ("pdr", "PDR (%)"), ("rec", "Recovery time (s)")]):
    for j, v in enumerate(vs):
        e = PV[v][k]
        ax.bar(j, e["mean"], color="white" if j != 1 else "0.75", edgecolor="k", hatch=hat[j], lw=0.7,
               yerr=[[e["mean"] - e["lo"]], [e["hi"] - e["mean"]]], capsize=2, error_kw=dict(lw=0.8))
    ax.set_xticks(range(5)); ax.set_xticklabels(short, fontsize=7.5); ax.set_ylabel(lab)
    if k == "pdr": ax.set_ylim(97.5, 100)
fig.tight_layout(); fig.savefig(f"{OUT}/fig6_ablation.png", bbox_inches="tight"); plt.close(fig)

# ---- Fig 7: scenarios
SC = R["scenarios"]
vs2 = ["newreno", "cubic", "bbr", "westwood", "ppo", "nc_full"]
fig, axs = plt.subplots(1, 3, figsize=(6.5, 2.8))
base = {"default": {v: PV[v] for v in vs2}}
for ax, (k, lab) in zip(axs, [("rtt", "Mean RTT (ms)"), ("pdr", "PDR (%)"), ("rec", "Recovery time (s)")]):
    w = 0.13
    for j, v in enumerate(vs2):
        vals = [PV[v][k]["mean"] if False else None for _ in range(3)]
        vals = [R["per_variant"][v][k]["mean"], SC["load8"][v][k]["mean"], SC["nlos"][v][k]["mean"]]
        ax.bar(np.arange(3) + (j - 2.5) * w, vals, w, color="0.75" if v == "nc_full" else "white", edgecolor="k", lw=0.6,
               hatch=[None, "///", "\\\\\\", "xxx", "...", None][j], label=NAMES[v])
    ax.set_xticks(range(3)); ax.set_xticklabels(["Base\n(4 UE)", "Load\n(8 UE)", "NLOS\n(4 UE)"], fontsize=7.5); ax.set_ylabel(lab)
    if k == "pdr": ax.set_ylim(95, 100)
h, l = axs[0].get_legend_handles_labels()
fig.legend(h, l, ncol=6, loc="lower center", bbox_to_anchor=(0.5, -0.06), fontsize=7.5)
fig.tight_layout(); fig.savefig(f"{OUT}/fig7_scenarios.png", bbox_inches="tight"); plt.close(fig)

# ---- Fig 8: training curves
fig, axs = plt.subplots(1, 2, figsize=(6.5, 2.6))
for v, ls, mk in [("ppo", "--", "s"), ("nc_full", "-", "o"), ("nc_nodrtd", ":", "^"), ("nc_noamabcs", "-.", "v")]:
    its, rt, th = [], [], []
    for line in open(f"{WORK}/train_{v}.log"):
        m = re.match(r"iter (\d+)/\d+ .*thr=([\d.]+) rtt=([\d.]+)", line)
        if m: its.append(int(m.group(1))); th.append(float(m.group(2))); rt.append(float(m.group(3)))
    axs[0].plot(its, rt, ls=ls, marker=mk, ms=2.5, color="k", lw=1, label=NAMES[v])
    axs[1].plot(its, th, ls=ls, marker=mk, ms=2.5, color="k", lw=1, label=NAMES[v])
axs[0].set_xlabel("PPO iteration"); axs[0].set_ylabel("Training RTT (ms)")
axs[1].set_xlabel("PPO iteration"); axs[1].set_ylabel("Training goodput (Mbps)")
axs[0].legend(fontsize=7)
fig.tight_layout(); fig.savefig(f"{OUT}/fig8_training.png", bbox_inches="tight"); plt.close(fig)
print("ok")
