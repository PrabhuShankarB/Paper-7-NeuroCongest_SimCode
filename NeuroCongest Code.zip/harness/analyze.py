"""Aggregate real NS-3 results: per-variant means, paired differences vs NeuroCongest, bootstrap CIs, Wilcoxon."""
import sys, json
sys.path.insert(0, "/home/claude/nc")
import numpy as np
from scipy import stats
from nc_lib import *

SEEDS = list(range(201, 221))
V = {"newreno": "cl_newreno_{s}", "cubic": "cl_cubic_{s}", "bbr": "cl_bbr_{s}", "westwood": "cl_westwood_{s}",
     "ppo": "ev_ppo_{s}", "nc_full": "ev_nc_full_{s}", "nc_notasi": "ev_nc_notasi_{s}",
     "nc_nodrtd": "ev_nc_nodrtd_{s}", "nc_noamabcs": "ev_nc_noamabcs_{s}"}
for _v in ["vegas","illinois","yeah","highspeed","veno","htcp","bic","hybla"]:
    V[_v] = "cl_%s_{s}" % _v
KEYS = ["thr", "rtt", "pdr", "cv", "rec"]
R = {}
for v, pat in V.items():
    rows = []
    for s in SEEDS:
        p = f"{WORK}/{pat.format(s=s)}_summary.txt"
        try:
            rows.append(run_metrics(p))
        except Exception:
            rows.append(None)
    R[v] = rows


def col(v, k):
    return np.array([r[k] if r else np.nan for r in R[v]])


def boot(x, n=5000, seed=0):
    x = x[~np.isnan(x)]
    rng = np.random.default_rng(seed)
    m = np.array([rng.choice(x, len(x)).mean() for _ in range(n)])
    return np.percentile(m, [2.5, 97.5])


out = {"per_variant": {}, "paired_vs_nc_full": {}}
print(f"{'variant':12s} " + " ".join(f"{k:>16s}" for k in KEYS))
for v in V:
    row = {}
    s = []
    for k in KEYS:
        x = col(v, k)
        if np.all(np.isnan(x)):
            s.append(f"{'n/a':>16s}"); continue
        lo, hi = boot(x)
        row[k] = dict(mean=float(np.nanmean(x)), sd=float(np.nanstd(x, ddof=1)), lo=float(lo), hi=float(hi), n=int((~np.isnan(x)).sum()))
        s.append(f"{np.nanmean(x):7.2f}[{lo:5.1f},{hi:5.1f}]")
    out["per_variant"][v] = row
    print(f"{v:12s} " + " ".join(s))

print("\npaired difference (variant - nc_full) per key: mean diff [95% boot CI], Wilcoxon p")
for v in V:
    if v == "nc_full":
        continue
    d = {}
    line = []
    for k in KEYS:
        a, b = col("nc_full", k), col(v, k)
        ok = ~np.isnan(a) & ~np.isnan(b)
        if ok.sum() < 5:
            continue
        diff = a[ok] - b[ok]            # positive => nc_full larger
        lo, hi = boot(diff)
        try:
            p = stats.wilcoxon(diff).pvalue
        except Exception:
            p = float("nan")
        d[k] = dict(diff=float(diff.mean()), lo=float(lo), hi=float(hi), p=float(p), n=int(ok.sum()))
        line.append(f"{k}:{diff.mean():+.2f}[{lo:+.2f},{hi:+.2f}] p={p:.3f}")
    out["paired_vs_nc_full"][v] = d
    print(f"nc_full - {v:12s} " + "  ".join(line))
json.dump(out, open(f"{WORK}/results.json", "w"), indent=1)

# ---- robustness scenarios (seeds 201-210)
SC = {}
for scen in ["load8", "nlos"]:
    SC[scen] = {}
    for v in ["newreno", "cubic", "bbr", "westwood", "ppo", "nc_full"]:
        rows = []
        for sd in range(201, 211):
            try:
                rows.append(run_metrics(f"{WORK}/sc_{scen}_{v}_{sd}_summary.txt"))
            except Exception:
                rows.append(None)
        SC[scen][v] = rows
out["scenarios"] = {}
for scen, d in SC.items():
    print(f"\nscenario {scen} (mean over seeds; paired diff nc_full - variant)")
    out["scenarios"][scen] = {}
    nc = {k: np.array([r[k] if r else np.nan for r in d["nc_full"]]) for k in KEYS}
    for v, rows in d.items():
        x = {k: np.array([r[k] if r else np.nan for r in rows]) for k in KEYS}
        e = {}; line = []
        for k in KEYS:
            ok = ~np.isnan(x[k]) & ~np.isnan(nc[k])
            e[k] = dict(mean=float(np.nanmean(x[k])) if ok.any() else None, n=int((~np.isnan(x[k])).sum()))
            if v != "nc_full" and ok.sum() >= 5:
                df = nc[k][ok] - x[k][ok]
                try: p = stats.wilcoxon(df).pvalue
                except Exception: p = float("nan")
                e[k].update(diff=float(df.mean()), p=float(p))
            line.append(f"{k}:{e[k]['mean'] if e[k]['mean'] is None else round(e[k]['mean'],2)}")
        out["scenarios"][scen][v] = e
        print(f"  {v:10s} " + "  ".join(line))
json.dump(out, open(f"{WORK}/results.json", "w"), indent=1)
