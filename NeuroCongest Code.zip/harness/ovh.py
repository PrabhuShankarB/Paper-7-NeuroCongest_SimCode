import sys; sys.path.insert(0,'/home/claude/nc')
from nc_lib import *
exec(open('/home/claude/nc/eval.py').read().split("jobs =")[0].split("from nc_lib import *")[1])
res={}
for v,c in cfg.items():
    sm,_=run_ns3(v,201,f"ovh_{v}",**c)
    for l in open(sm):
        if l.startswith("ovh"): res[v]=l.split()[1:]
    m=run_metrics(sm); m0=run_metrics(f"{WORK}/ev_{v}_201_summary.txt")
    res[v]+= [abs(m['thr']-m0['thr'])<1e-9]
print(res)
