import sys; sys.path.insert(0,'/home/claude/nc')
from nc_lib import *
VS=["vegas","illinois","yeah","highspeed","veno","htcp","bic","hybla"]
jobs=[dict(variant=v, seed=s, tag=f"cl_{v}_{s}") for v in VS for s in range(201,221)]
res=run_many(jobs, workers=2)
print("done", sum(1 for r,_ in res if r is None), "failed")
