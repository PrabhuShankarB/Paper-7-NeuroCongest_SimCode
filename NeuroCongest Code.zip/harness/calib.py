import sys; sys.path.insert(0,'/home/claude/nc')
from nc_lib import *
jobs=[dict(variant="newreno", seed=s, tag=f"calib_{s}", sim=16.0, ues=4, extra=["--calib=1"]) for s in range(301,309)]
res=run_many(jobs, workers=2)
print("calib done", sum(1 for r,_ in res if r is None), "failed")
