import sys, json; sys.path.insert(0,'/home/claude/nc')
from nc_lib import *
SEEDS=list(range(201,221))
jobs=[dict(variant=v, seed=s, tag=f"cl_{v}_{s}") for v in ["newreno","cubic","bbr","westwood"] for s in SEEDS]
res=run_many(jobs, workers=2)
print("done", len(res), sum(1 for r,_ in res if r is None), "failed")
