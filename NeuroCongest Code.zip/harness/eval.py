"""Evaluate all variants on matched seeds (201-220), same mobility/channel realisation per seed."""
import sys, os, json
sys.path.insert(0, "/home/claude/nc")
os.environ.pop("NC_REUSE", None) if len(sys.argv) > 1 and sys.argv[1] == "fresh" else None
from nc_lib import *

SEEDS = list(range(201, 221))
W = WORK
cfg = {
    "ppo":         dict(policy=f"{W}/pol_ppo.txt"),
    "nc_full":     dict(policy=f"{W}/pol_nc_full.txt", imprint=f"{W}/imp_nc_full.txt", chan=f"{W}/f_drtd.txt"),
    "nc_notasi":   dict(policy=f"{W}/pol_nc_full.txt", chan=f"{W}/f_drtd.txt"),
    "nc_nodrtd":   dict(policy=f"{W}/pol_nc_nodrtd.txt", imprint=f"{W}/imp_nc_nodrtd.txt"),
    "nc_noamabcs": dict(policy=f"{W}/pol_nc_noamabcs.txt", imprint=f"{W}/imp_nc_noamabcs.txt", chan=f"{W}/f_drtd.txt"),
}
jobs = [dict(variant=v, seed=s, tag=f"ev_{v}_{s}", **c) for v, c in cfg.items() for s in SEEDS]
res = run_many(jobs, workers=2)
print("eval done", sum(1 for r, _ in res if r is None), "failed")
