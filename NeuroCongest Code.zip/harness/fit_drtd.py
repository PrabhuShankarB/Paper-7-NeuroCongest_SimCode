"""Fit DRTD-CD channel-delay function f(RSRP, SINR, Doppler) -> RTT_ch (ms) from light-load NS-3 runs.
Light load (300 kb/s TCP) keeps queueing negligible, so RTT minus the path floor is channel/access-attributable."""
import sys, glob
import numpy as np
sys.path.insert(0, "/home/claude/nc")
from nc_lib import MLP, Adam

files = sorted(glob.glob("/home/claude/nc/work/calib_*_calib.txt"))
D = np.vstack([np.loadtxt(f) for f in files if open(f).read().strip()])
rsrp, sinr, dop, rtt = D[:, 2], D[:, 3], D[:, 4], D[:, 5]
prop = np.percentile(rtt, 2)
y = np.clip(rtt - prop, 0, None)
X = np.stack([(rsrp + 100) / 40.0, sinr / 30.0, dop / 200.0], 1)
n = len(X)
rng = np.random.default_rng(0)
idx = rng.permutation(n)
tr, te = idx[: int(0.8 * n)], idx[int(0.8 * n):]
f = MLP([3, 16, 1], "relu", 3, out_scale=0.1)
opt = Adam(f.params(), 3e-3)
for ep in range(400):
    p = rng.permutation(tr)
    for i in range(0, len(p), 256):
        b = p[i:i + 256]
        o, hs = f.forward(X[b], cache=True)
        d = 2 * (o[:, 0] - y[b])[:, None] / len(b)
        gW, gb = f.backward(hs, d)
        opt.step(f.params(), gW + gb)
pred = f.forward(X[te])[:, 0]
mse = float(np.mean((pred - y[te]) ** 2))
base = float(np.mean((y[te] - y[tr].mean()) ** 2))
print(f"samples={n} rtt_prop(2nd pct)={prop:.2f} ms  y mean={y.mean():.3f} sd={y.std():.3f}  test MSE={mse:.4f} vs mean-predictor {base:.4f}")
f.save("/home/claude/nc/work/f_drtd.txt")
open("/home/claude/nc/work/f_drtd_stats.txt", "w").write(
    f"samples {n}\nrtt_prop_ms {prop:.3f}\ny_mean {y.mean():.4f}\ny_sd {y.std():.4f}\ntest_mse {mse:.5f}\nmean_predictor_mse {base:.5f}\n")
