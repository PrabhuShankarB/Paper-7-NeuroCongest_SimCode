import sys, os; sys.path.insert(0,'/home/claude/nc')
os.environ["NC_REUSE"]="1"
from nc_lib import *
W=WORK
cfg={"newreno":{}, "cubic":{}, "bbr":{}, "westwood":{},
 "ppo":dict(policy=f"{W}/pol_ppo.txt"),
 "nc_full":dict(policy=f"{W}/pol_nc_full.txt", imprint=f"{W}/imp_nc_full.txt", chan=f"{W}/f_drtd.txt")}
scen={"load8":(8,[]), "nlos":(4,["--chCond=NLOS"])}
jobs=[dict(variant=v, seed=s, tag=f"sc_{n}_{v}_{s}", ues=u, extra=ex, **c)
      for n,(u,ex) in scen.items() for v,c in cfg.items() for s in range(201,211)]
res=run_many(jobs, workers=2)
print("done", sum(1 for r,_ in res if r is None), "failed")
