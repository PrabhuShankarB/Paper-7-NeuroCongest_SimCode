"""Sim-in-the-loop PPO training for NeuroCongest variants (real NS-3 episodes).
usage: python3 train.py <variant> <iters> <eps_per_iter> [imprint_iters]
Writes work/pol_<variant>.txt (+ work/imp_<variant>.txt for TASI variants) and work/train_<variant>.log
"""
import sys, os, json, time
os.environ.pop("NC_REUSE", None)
import numpy as np
sys.path.insert(0, "/home/claude/nc")
from nc_lib import *

variant = sys.argv[1]
iters = int(sys.argv[2])
eps = int(sys.argv[3])
imp_iters = int(sys.argv[4]) if len(sys.argv) > 4 else 0
TRAIN_SEEDS = list(range(1, 101))          # evaluation seeds (201+) are disjoint
rng = np.random.default_rng(sum(map(ord, variant)))
pol = f"{WORK}/pol_{variant}.txt"
chan = f"{WORK}/f_drtd.txt" if variant in ("nc_full", "nc_notasi", "nc_noamabcs") else None
log = open(f"{WORK}/train_{variant}.log", "a")


def say(*a):
    s = " ".join(str(x) for x in a)
    print(s, flush=True)
    log.write(s + "\n"); log.flush()


def episodes(tagp, imprint=None):
    seeds = rng.choice(TRAIN_SEEDS, eps, replace=False)
    jobs = [dict(variant=variant, seed=int(sd), tag=f"{tagp}_{k}", policy=pol, chan=chan, imprint=imprint,
                 traj=f"{WORK}/{tagp}_{k}.traj", stochastic=True) for k, sd in enumerate(seeds)]
    res = run_many(jobs, workers=2)
    out = []
    for j, (sm, _) in zip(jobs, res):
        if sm is None:
            continue
        T = load_traj(j["traj"], IN_DIM[variant])
        if T is not None:
            out.append(T)
        os.remove(j["traj"]) if os.path.exists(j["traj"]) else None
    return out, [run_metrics(sm) for sm, _ in res if sm is not None]


ppo = Ppo(variant, seed=sum(map(ord, variant)) % 1000)
if os.path.exists(pol + ".critic") and os.path.exists(pol):
    ppo.actor.load(pol); ppo.critic.load(pol + ".critic")
    say("resumed")
start = int(open(pol + ".iter").read()) if os.path.exists(pol + ".iter") else 0
ppo.actor.save(pol); ppo.critic.save(pol + ".critic")
for it in range(start, iters):
    t0 = time.time()
    trajs, ms = episodes(f"tr_{variant}")
    st = ppo.update(trajs)
    ppo.actor.save(pol); ppo.critic.save(pol + ".critic")
    open(pol + ".iter", "w").write(str(it + 1))
    say(f"iter {it+1}/{iters} n={st['n']} ent={st['ent']:.3f} thr={np.mean([m['thr'] for m in ms]):.1f} "
        f"rtt={np.mean([m['rtt'] for m in ms]):.1f} pdr={np.mean([m['pdr'] for m in ms]):.2f} "
        f"rec={np.nanmean([m['rec'] for m in ms]):.2f} t={time.time()-t0:.0f}s")

# ------------------------------------------------ TASI: per-cell output-layer imprints (delta theta_cell)
if imp_iters and variant != "ppo":
    imp = f"{WORK}/imp_{variant}.txt"
    cells = [1, 3, 5]
    base = [p.copy() for p in ppo.actor.params()]
    nL = len(ppo.actor.W)
    dW = {c: np.zeros_like(ppo.actor.W[-1]) for c in cells}
    dB = {c: np.zeros_like(ppo.actor.b[-1]) for c in cells}

    def write_imp():
        with open(imp, "w") as fh:
            fh.write(f"{len(cells)}\n")
            for c in cells:
                fh.write(f"{c} {dW[c].size} {dB[c].size}\n")
                fh.write(" ".join(f"{x:.9g}" for x in dW[c].ravel()) + "\n")
                fh.write(" ".join(f"{x:.9g}" for x in dB[c].ravel()) + "\n")

    write_imp()
    for it in range(imp_iters):
        t0 = time.time()
        trajs, ms = episodes(f"im_{variant}", imprint=imp)
        for c in cells:
            sub = []
            for T in trajs:
                Tc = T[T[:, 2] == c]
                if len(Tc) >= 20:
                    sub.append(Tc)
            if not sub:
                continue
            # actor with theta_base + delta_c, update only the output layer
            ppo.actor.W[-1] = base[nL - 1] + dW[c]
            ppo.actor.b[-1] = base[2 * nL - 1] + dB[c]
            ppo.update(sub, epochs=3, only_last=True, fit_critic=False)
            dW[c] = ppo.actor.W[-1] - base[nL - 1]
            dB[c] = ppo.actor.b[-1] - base[2 * nL - 1]
        # restore base for the next cell/iteration
        ppo.actor.W[-1] = base[nL - 1].copy(); ppo.actor.b[-1] = base[2 * nL - 1].copy()
        write_imp()
        say(f"imprint iter {it+1}/{imp_iters} |dW|=" + ",".join(f"{np.abs(dW[c]).mean():.4f}" for c in cells) +
            f" thr={np.mean([m['thr'] for m in ms]):.1f} rec={np.nanmean([m['rec'] for m in ms]):.2f} t={time.time()-t0:.0f}s")
say("done")
