// NeuroCongest packet-level experiment: NS-3 3.46 + 5G-LENA (NR) with real X2 handovers.
// One TCP bulk flow per UE, sender at the remote host. The congestion controller under test is
// selected per run: built-in TCP variants, or the NeuroCongest family (executed policy).
//
// Everything reported is produced by executing the controller inside the simulator.
// Honest scope notes (also stated in the paper):
//  - single sub-6 GHz band, UMa channel, homogeneous macro cells (no cross-band tiers, no LEO)
//  - handovers are network-initiated X2 handovers scheduled at the geometric cell boundary
//  - radio measurements (RSRP, SINR) reach the sender through a cross-layer side channel
//  - AMABCS forecast is a linear AR extrapolation, not an LSTM

#include "ns3/antenna-module.h"
#include "ns3/applications-module.h"
#include "ns3/core-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/internet-module.h"
#include "ns3/mobility-module.h"
#include "ns3/network-module.h"
#include "ns3/nr-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/tcp-socket-base.h"

#include <chrono>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <map>
#include <sstream>
#include <vector>

using namespace ns3;
NS_LOG_COMPONENT_DEFINE("NeuroCongestExp");

// ------------------------------------------------------------------ small MLP (inference)
struct Mlp
{
    std::vector<int> dims;
    std::vector<std::vector<double>> W; // layer l: dims[l+1] x dims[l], row-major
    std::vector<std::vector<double>> b;
    bool relu{false};
    bool loaded{false};

    bool Load(const std::string& file)
    {
        std::ifstream f(file);
        if (!f)
        {
            return false;
        }
        int nl;
        f >> nl;
        dims.assign(nl + 1, 0);
        for (int i = 0; i <= nl; i++)
        {
            f >> dims[i];
        }
        W.assign(nl, {});
        b.assign(nl, {});
        for (int l = 0; l < nl; l++)
        {
            W[l].resize(dims[l + 1] * dims[l]);
            b[l].resize(dims[l + 1]);
            for (auto& x : W[l])
            {
                f >> x;
            }
            for (auto& x : b[l])
            {
                f >> x;
            }
        }
        loaded = true;
        return true;
    }

    std::vector<double> Forward(const std::vector<double>& in, const std::vector<double>* dW = nullptr,
                                const std::vector<double>* db = nullptr) const
    {
        std::vector<double> h = in;
        int nl = W.size();
        for (int l = 0; l < nl; l++)
        {
            std::vector<double> o(dims[l + 1]);
            for (int j = 0; j < dims[l + 1]; j++)
            {
                double s = b[l][j];
                if (l == nl - 1 && db)
                {
                    s += (*db)[j];
                }
                for (int i = 0; i < dims[l]; i++)
                {
                    double w = W[l][j * dims[l] + i];
                    if (l == nl - 1 && dW)
                    {
                        w += (*dW)[j * dims[l] + i];
                    }
                    s += w * h[i];
                }
                o[j] = s;
            }
            if (l < nl - 1)
            {
                for (auto& x : o)
                {
                    x = relu ? std::max(0.0, x) : std::tanh(x);
                }
            }
            h = o;
        }
        return h;
    }
};

// ------------------------------------------------------------------ run configuration
struct Cfg
{
    std::string variant{"newreno"}; // newreno|cubic|bbr|westwood|ppo|nc_full|nc_notasi|nc_nodrtd|nc_noamabcs
    std::string policyFile;
    std::string imprintFile;  // per-cell output-layer deltas (TASI)
    std::string chanFile;     // DRTD-CD f() weights
    std::string trajFile;     // training trajectory log
    bool stochastic{false};
    double simTime{16.0};
    uint32_t ueNum{4};
    uint32_t gnbNum{3};
    double isd{200.0};
    uint32_t ueCols{2};            // UE antenna columns (1 = single isotropic element, no UE-side beamforming)
    std::string rlcMode{"RlcUmAlways"}; // RlcUmAlways | RlcAmAlways (AM deadlocks after a deep fade: no re-segmentation of retx PDUs)
    std::string chCond{"Default"}; // Default (3GPP UMa LOS probability) | LOS | NLOS
    std::string hoMode{"geo"};     // a3 (RSRP A3 event, measurement based) | geo (geometric midpoint)
    double hoOff{40.0};             // geo mode: handover this many metres past the cell-boundary midpoint
    double a3Hys{3.0};
    double a3TttMs{160.0};
    double epoch{0.020};
    uint32_t seed{1};
    std::string outPrefix{"run"};
    bool calib{false};
};
Cfg g_cfg;

// Cross-layer channel feed per UE
struct Chan
{
    double rsrp{-80};
    double sinr{15};
    double doppler{0};
    uint16_t cell{1};
    double lastHoEnd{-100};
    int hoCount{0};
};
std::vector<Chan> g_chan;
bool g_diag = false;
bool g_diagNoLoad = false;
std::map<uint32_t, std::map<int,int>> g_s1u; // node -> 0.5s bin -> pkts
void DiagS1u(std::string ctx, Ptr<Packet> p){ uint32_t n=std::stoul(ctx.substr(10)); g_s1u[n][(int)(Simulator::Now().GetSeconds()*2)]++; }
void DiagUeSt(std::string c, uint64_t imsi, uint16_t cell, uint16_t rnti, NrUeRrc::State o, NrUeRrc::State n){ std::cerr<<Simulator::Now().GetSeconds()<<" UE imsi "<<imsi<<" cell "<<cell<<" rnti "<<rnti<<" "<<NrUeRrc::ToString(o)<<" -> "<<NrUeRrc::ToString(n)<<"\n"; }
void DiagGnbSt(std::string c, uint64_t imsi, uint16_t cell, uint16_t rnti, NrUeManager::State o, NrUeManager::State n){ std::cerr<<Simulator::Now().GetSeconds()<<" GNB cell "<<cell<<" imsi "<<imsi<<" rnti "<<rnti<<" "<<(int)o<<" -> "<<(int)n<<"\n"; }
void DiagTmo(std::string c, uint64_t imsi, uint16_t rnti, uint16_t cell, std::string cause){ std::cerr<<Simulator::Now().GetSeconds()<<" RRC TIMEOUT cell "<<cell<<" rnti "<<rnti<<" "<<cause<<"\n"; }
std::map<std::string, std::map<int,int>> g_rlc;
void DiagRlcTx(std::string c, uint16_t rnti, uint8_t lcid, uint32_t sz){ size_t a=c.find("/NodeList/")+10; g_rlc["gnbTx node"+c.substr(a,c.find('/',a)-a)+" rnti"+std::to_string(rnti)][(int)(Simulator::Now().GetSeconds()*2)]++; }
void DiagRlcRx(std::string c, uint16_t rnti, uint8_t lcid, uint32_t sz, uint64_t d){ size_t a=c.find("/NodeList/")+10; g_rlc["ueRx node"+c.substr(a,c.find('/',a)-a)+" rnti"+std::to_string(rnti)][(int)(Simulator::Now().GetSeconds()*2)]++; }
void DiagPdcpRx(std::string c, uint16_t rnti, uint8_t lcid, uint32_t sz, uint64_t d){ size_t a=c.find("/NodeList/")+10; g_rlc["uePdcpRx node"+c.substr(a,c.find('/',a)-a)+" rnti"+std::to_string(rnti)][(int)(Simulator::Now().GetSeconds()*2)]++; }
void DiagConnectUe(){ Config::Connect("/NodeList/*/DeviceList/*/$ns3::NrUeNetDevice/NrUeRrc/DataRadioBearerMap/*/NrPdcp/RxPDU", MakeCallback(&DiagPdcpRx)); Config::Connect("/NodeList/*/DeviceList/*/$ns3::NrUeNetDevice/NrUeRrc/DataRadioBearerMap/*/NrRlc/RxPDU", MakeCallback(&DiagRlcRx)); }
void DiagConnectGnb(){ Config::Connect("/NodeList/*/DeviceList/*/$ns3::NrGnbNetDevice/NrGnbRrc/UeMap/*/DataRadioBearerMap/*/NrRlc/TxPDU", MakeCallback(&DiagRlcTx)); }
std::map<std::string, std::map<int,int>> g_ip;
void DiagIpRx(std::string c, Ptr<const Packet> p, Ptr<Ipv4> ip, uint32_t i){ size_t a=c.find("/NodeList/")+10; g_ip["ipRx node"+c.substr(a,c.find('/',a)-a)][(int)(Simulator::Now().GetSeconds()*2)]++; }
void DiagIpDrop(std::string c, const Ipv4Header& h, Ptr<const Packet> p, Ipv4L3Protocol::DropReason r, Ptr<Ipv4> ip, uint32_t i){ size_t a=c.find("/NodeList/")+10; g_ip["ipDrop node"+c.substr(a,c.find('/',a)-a)+" reason"+std::to_string((int)r)][(int)(Simulator::Now().GetSeconds()*2)]++; }
std::map<std::string, std::pair<double,int>> g_sinrAcc;
void DiagSinr(std::string c, uint16_t cell, uint16_t rnti, double sinr, uint16_t bwp){ size_t a=c.find("/NodeList/")+10; std::string k="sinr node"+c.substr(a,c.find('/',a)-a)+" rnti"+std::to_string(rnti)+" t"+std::to_string((int)(Simulator::Now().GetSeconds()*4)); auto& e=g_sinrAcc[k]; e.first+=10*std::log10(std::max(sinr,1e-9)); e.second++; }
void DiagMeas(std::string c, uint16_t rnti, uint16_t cell, double rsrp, double rsrq, bool serving, uint8_t cc){ size_t a=c.find("/NodeList/")+10; std::string n=c.substr(a,c.find('/',a)-a); if (n!="3") return; std::cerr<<"meas t="<<Simulator::Now().GetSeconds()<<" node"<<n<<" rnti"<<rnti<<" cell"<<cell<<" rsrp="<<rsrp<<" serving="<<serving<<"\n"; }
std::map<std::string,int> g_ctrl;
void DiagCtrl(std::string c, SfnSf sf, uint16_t cell, uint16_t rnti, uint8_t bwp, Ptr<const NrControlMessage> m){ if (Simulator::Now().GetSeconds()<2.75) return; std::string k="ueCtrl type"+std::to_string((int)m->GetMessageType())+" cell"+std::to_string(cell)+" rnti"+std::to_string(rnti); auto dl=DynamicCast<NrUlDciMessage>(ConstCast<NrControlMessage>(m)); if(dl){ k+=" ULDCI-for-rnti"+std::to_string(dl->GetDciInfoElement()->m_rnti);} g_ctrl[k]++; if (rnti>=300) g_rlc["ctl"+k.substr(7)][(int)(Simulator::Now().GetSeconds()*2)]++; }
std::vector<double> g_hoTimes[16];       // per UE
static double g_decNs = 0;
static uint64_t g_decN = 0;
std::vector<std::ostringstream*> g_calibOut;
std::ofstream g_trajOut;
std::ofstream g_calibFile;

class NcOps;
std::vector<NcOps*> g_ops;

// ------------------------------------------------------------------ the controller
static const int K_ARMS = 5;
static const double ARMS[K_ARMS] = {0.80, 0.95, 1.00, 1.05, 1.20};

class NcOps : public TcpNewReno
{
  public:
    static TypeId GetTypeId()
    {
        static TypeId tid = TypeId("ns3::NcOps").SetParent<TcpNewReno>().AddConstructor<NcOps>();
        return tid;
    }
    NcOps() = default;
    NcOps(const NcOps& o) = default;
    void SetUe(uint32_t u) { m_ue = u; }
    std::string GetName() const override { return "NcOps"; }
    Ptr<TcpCongestionOps> Fork() override { return CopyObject<NcOps>(this); }

    void Setup()
    {
        const std::string& v = g_cfg.variant;
        m_useC = (v == "nc_full" || v == "nc_notasi" || v == "nc_noamabcs" || v == "nc_nodrtd");
        m_useHo = m_useC;
        m_useDrtd = (v == "nc_full" || v == "nc_notasi" || v == "nc_noamabcs");
        m_useAmab = (v == "nc_full" || v == "nc_notasi" || v == "nc_nodrtd");
        m_useTasi = (v == "nc_full" || v == "nc_noamabcs" || v == "nc_nodrtd");
        m_actor.relu = false;
        m_actor.Load(g_cfg.policyFile);
        if (m_useDrtd)
        {
            m_f.relu = true;
            m_f.Load(g_cfg.chanFile);
        }
        if (m_useTasi)
        {
            LoadImprints(g_cfg.imprintFile);
        }
        m_inDim = 5 + (m_useHo ? 1 : 0) + (m_useC ? 3 : 0) + (m_useDrtd ? 3 : 0) + (m_useAmab ? 1 : 0);
        m_ready = true;
    }

    void LoadImprints(const std::string& file)
    {
        std::ifstream f(file);
        if (!f)
        {
            return;
        }
        int n;
        f >> n;
        for (int i = 0; i < n; i++)
        {
            int cell, nw, nb;
            f >> cell >> nw >> nb;
            std::vector<double> dw(nw), db(nb);
            for (auto& x : dw) f >> x;
            for (auto& x : db) f >> x;
            m_dW[cell] = dw;
            m_dB[cell] = db;
        }
    }

    // TASI restoration: theta_active = theta_base + delta_theta_cell (single vector addition)
    void OnHandover(uint16_t cell)
    {
        m_activeCell = 0;
        if (m_useTasi && m_dW.count(cell))
        {
            m_activeCell = cell;
        }
        m_hoTime = Simulator::Now().GetSeconds();
        m_hoSeen = true;
    }

    uint32_t GetSsThresh(Ptr<const TcpSocketState> tcb, uint32_t bif) override
    {
        uint32_t seg = tcb->m_segmentSize;
        double base = 0.5;
        if (m_useDrtd && m_ready && !m_lastCongFlag)
        {
            base = 0.85; // attributed to channel: gentle reduction (Algorithm 3 semantics)
        }
        m_lossEpoch++;
        return std::max<uint32_t>(2 * seg, (uint32_t)(base * std::max<uint32_t>(bif, tcb->m_cWnd.Get())));
    }

    void PktsAcked(Ptr<TcpSocketState> tcb, uint32_t segAcked, const Time& rtt) override
    {
        m_ackedBytes += segAcked * tcb->m_segmentSize;
        if (!rtt.IsZero())
        {
            double r = rtt.GetSeconds() * 1000.0;
            m_rttLast = r;
            m_rttSum += r;
            m_rttN++;
            if (m_minRtt <= 0 || r < m_minRtt)
            {
                m_minRtt = r;
            }
            m_srtt = (m_srtt <= 0) ? r : 0.875 * m_srtt + 0.125 * r;
        }
    }

    void IncreaseWindow(Ptr<TcpSocketState> tcb, uint32_t segAcked) override
    {
        if (tcb->m_cWnd < tcb->m_ssThresh)
        {
            segAcked = SlowStart(tcb, segAcked);
            if (segAcked == 0)
            {
                return;
            }
        }
        double now = Simulator::Now().GetSeconds();
        if (m_lastDecision < 0)
        {
            m_lastDecision = now;
            m_lastCwndSeg = tcb->m_cWnd.Get() / tcb->m_segmentSize;
            return;
        }
        if (now - m_lastDecision < g_cfg.epoch)
        {
            return;
        }
        auto t0 = std::chrono::steady_clock::now();
        Decide(tcb, now);
        g_decNs += std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now() - t0).count();
        g_decN++;
    }

  private:
    void Decide(Ptr<TcpSocketState> tcb, double now)
    {
        double dt = now - m_lastDecision;
        uint32_t seg = tcb->m_segmentSize;
        double rate = (m_ackedBytes * 8.0 / dt) / 1e6; // Mbps delivery rate
        double rttMean = (m_rttN > 0) ? m_rttSum / m_rttN : m_rttLast;
        double minRtt = (m_minRtt > 0) ? m_minRtt : std::max(1.0, rttMean);
        double qr = std::min(4.0, std::max(0.0, (rttMean - minRtt) / minRtt));
        double loss = (m_lossEpoch > 0) ? 1.0 : 0.0;
        Chan& ch = g_chan[m_ue];

        // reward for the previous action (finalise previous transition)
        double reward = std::min(2.0, rate / 40.0) - 0.4 * qr - 0.6 * loss;
        if (m_havePrev && g_trajOut.is_open())
        {
            g_trajOut << m_ue << ' ' << std::fixed << std::setprecision(4) << m_prevT << ' ' << m_prevCell << ' '
                      << m_prevAct << ' ' << m_prevLogp << ' ' << reward << ' ' << 0;
            for (double x : m_prevState)
            {
                g_trajOut << ' ' << x;
            }
            g_trajOut << '\n';
        }

        // ---- DRTD-CD: channel / queue split with clamp (Eq. 15, 16)
        double rttCh = 0, rttQ = 0;
        bool congFlag = false;
        double rttProp = (m_minRtt > 0) ? m_minRtt : 1.0;
        if (m_useDrtd)
        {
            std::vector<double> in = {(ch.rsrp + 100.0) / 40.0, ch.sinr / 30.0, ch.doppler / 200.0};
            auto o = m_f.Forward(in);
            rttCh = std::max(0.0, o[0]);                          // ms, channel-attributable
            rttQ = std::max(0.0, rttMean - rttCh - rttProp);      // clamp at zero (Eq. 16)
            congFlag = rttQ > 0.15 * rttProp;                     // threshold theta_congestion
            m_lastCongFlag = congFlag;
        }

        // ---- AMABCS: forecast + UCB over arms; outputs a candidate only (Algorithm 4)
        double cand = 0.5;
        int candIdx = 2;
        if (m_useAmab)
        {
            // linear AR extrapolation of SINR, horizon k epochs
            double sinrF = ch.sinr + (ch.sinr - m_sinrPrev) * 5.0 * 0.5;
            m_sinrPrev = ch.sinr;
            double cap = 20.0 * std::log2(1.0 + std::pow(10.0, std::min(35.0, std::max(-5.0, sinrF)) / 10.0));
            cap = std::min(150.0, cap); // Mbps per-UE capacity estimate
            double cwndNow = tcb->m_cWnd.Get() * 8.0 / 1e6;
            double bestScore = -1e9;
            m_N += 1;
            for (int j = 0; j < K_ARMS; j++)
            {
                double w = cwndNow * ARMS[j];
                double thr = std::min(cap, w / (std::max(1.0, rttMean) / 1000.0));
                double qd = std::max(0.0, w / std::max(0.1, cap) * 1000.0 - rttProp);
                double rhat = 1.0 * std::min(2.0, thr / 40.0) - 0.4 * std::min(4.0, qd / std::max(1.0, rttProp));
                double ucb = rhat + 1.0 * std::sqrt(std::log(std::max(2.0, m_N)) / (1.0 + m_n[j]));
                if (ucb > bestScore)
                {
                    bestScore = ucb;
                    candIdx = j;
                }
            }
            m_n[candIdx] += 1;
            cand = candIdx / (double)(K_ARMS - 1);
        }

        // ---- state vector (Eq. 21 analogue)
        std::vector<double> s;
        s.push_back(std::min(3.0, (tcb->m_cWnd.Get() / (double)seg) / 100.0));
        s.push_back(std::min(5.0, rttMean / minRtt) / 2.0);
        s.push_back(qr / 2.0);
        s.push_back(std::min(2.0, rate / 40.0));
        s.push_back(loss);
        if (m_useHo)
        {
            double since = m_hoSeen ? (now - m_hoTime) : 100.0;
            s.push_back(std::exp(-since / 0.5));
        }
        if (m_useC)
        {
            s.push_back((ch.rsrp + 100.0) / 40.0);
            s.push_back(ch.sinr / 30.0);
            s.push_back(ch.doppler / 200.0);
        }
        if (m_useDrtd)
        {
            s.push_back(std::min(2.0, rttCh / minRtt));
            s.push_back(std::min(2.0, rttQ / minRtt));
            s.push_back(congFlag ? 1.0 : 0.0);
        }
        if (m_useAmab)
        {
            s.push_back(cand);
        }

        // ---- policy (PPO actor) with final authority
        const std::vector<double>* dW = nullptr;
        const std::vector<double>* dB = nullptr;
        if (m_activeCell && m_dW.count(m_activeCell))
        {
            dW = &m_dW[m_activeCell];
            dB = &m_dB[m_activeCell];
        }
        std::vector<double> logits = m_actor.Forward(s, dW, dB);
        double mx = *std::max_element(logits.begin(), logits.end());
        std::vector<double> p(K_ARMS);
        double z = 0;
        for (int j = 0; j < K_ARMS; j++)
        {
            p[j] = std::exp(logits[j] - mx);
            z += p[j];
        }
        for (auto& x : p) x /= z;
        int act = 0;
        if (g_cfg.stochastic)
        {
            Ptr<UniformRandomVariable> u = CreateObject<UniformRandomVariable>();
            double r = u->GetValue(0, 1), c = 0;
            for (int j = 0; j < K_ARMS; j++)
            {
                c += p[j];
                if (r <= c)
                {
                    act = j;
                    break;
                }
                act = j;
            }
        }
        else
        {
            act = std::max_element(p.begin(), p.end()) - p.begin();
        }

        uint32_t newCwnd = (uint32_t)std::max(2.0 * seg, tcb->m_cWnd.Get() * ARMS[act]);
        tcb->m_cWnd = newCwnd;

        m_prevState = s;
        m_prevAct = act;
        m_prevLogp = std::log(std::max(1e-9, p[act]));
        m_prevT = now;
        m_prevCell = ch.cell;
        m_havePrev = true;
        m_lastDecision = now;
        m_ackedBytes = 0;
        m_rttSum = 0;
        m_rttN = 0;
        m_lossEpoch = 0;
    }

    uint32_t m_ue{0};
    bool m_useC{false}, m_useHo{false}, m_useDrtd{false}, m_useAmab{false}, m_useTasi{false};
    bool m_ready{false};
    int m_inDim{0};
    Mlp m_actor, m_f;
    std::map<int, std::vector<double>> m_dW, m_dB;
    int m_activeCell{0};
    bool m_hoSeen{false};
    double m_hoTime{0};
    double m_lastDecision{-1};
    uint32_t m_lastCwndSeg{0};
    uint64_t m_ackedBytes{0};
    double m_rttSum{0}, m_rttLast{0}, m_minRtt{-1}, m_srtt{-1};
    int m_rttN{0};
    int m_lossEpoch{0};
    bool m_lastCongFlag{true};
    double m_sinrPrev{15};
    double m_N{1};
    double m_n[K_ARMS] = {0, 0, 0, 0, 0};
    bool m_havePrev{false};
    std::vector<double> m_prevState;
    int m_prevAct{0};
    double m_prevLogp{0};
    double m_prevT{0};
    int m_prevCell{0};
};
NS_OBJECT_ENSURE_REGISTERED(NcOps);

// ------------------------------------------------------------------ measurement plumbing
static uint32_t NodeFromContext(const std::string& ctx)
{
    size_t p = ctx.find("/NodeList/");
    size_t q = ctx.find('/', p + 10);
    return std::stoul(ctx.substr(p + 10, q - p - 10));
}
std::map<uint32_t, uint32_t> g_nodeToUe;

void
OnMeas(std::string ctx, uint16_t rnti, uint16_t cell, double rsrpDbm, double rsrq, bool serving, uint8_t cc)
{
    if (!serving)
    {
        return;
    }
    auto it = g_nodeToUe.find(NodeFromContext(ctx));
    if (it == g_nodeToUe.end())
    {
        return;
    }
    Chan& c = g_chan[it->second];
    c.rsrp = rsrpDbm;
    c.cell = cell;
}
void
OnSinr(std::string ctx, uint16_t cell, uint16_t rnti, double sinrLin, uint16_t bwp)
{
    auto it = g_nodeToUe.find(NodeFromContext(ctx));
    if (it == g_nodeToUe.end())
    {
        return;
    }
    g_chan[it->second].sinr = 10.0 * std::log10(std::max(1e-6, sinrLin));
}
void
OnHoEnd(std::string ctx, uint64_t imsi, uint16_t cell, uint16_t rnti)
{
    auto it = g_nodeToUe.find(NodeFromContext(ctx));
    if (it == g_nodeToUe.end())
    {
        return;
    }
    uint32_t u = it->second;
    g_chan[u].cell = cell;
    g_chan[u].lastHoEnd = Simulator::Now().GetSeconds();
    g_chan[u].hoCount++;
    g_hoTimes[u].push_back(Simulator::Now().GetSeconds());
    if (g_ops[u])
    {
        g_ops[u]->OnHandover(cell);
    }
}

std::vector<std::vector<double>> g_goodBins; // per UE, 100 ms bins
std::vector<std::vector<double>> g_rtt;      // per UE rtt samples (ms)
std::vector<std::vector<double>> g_cwnd;     // per UE cwnd samples (bytes), at each change
std::vector<double> g_prevRtt;

void
SinkRx(uint32_t ue, Ptr<const Packet> p, const Address&)
{
    size_t bin = (size_t)(Simulator::Now().GetSeconds() * 10.0);
    auto& v = g_goodBins[ue];
    if (v.size() <= bin)
    {
        v.resize(bin + 1, 0.0);
    }
    v[bin] += p->GetSize();
}
void
RttCb(uint32_t ue, Time oldv, Time newv)
{
    g_rtt[ue].push_back(newv.GetSeconds() * 1000.0);
}
void
CwndCb(uint32_t ue, uint32_t oldv, uint32_t newv)
{
    g_cwnd[ue].push_back(newv);
}

void
AttachCc(uint32_t ue, Ptr<BulkSendApplication> app)
{
    Ptr<Socket> s = app->GetSocket();
    Ptr<TcpSocketBase> tsb = DynamicCast<TcpSocketBase>(s);
    if (!tsb)
    {
        return;
    }
    const std::string& v = g_cfg.variant;
    if (v == "ppo" || v.rfind("nc_", 0) == 0)
    {
        Ptr<NcOps> ops = CreateObject<NcOps>();
        ops->SetUe(ue);
        ops->Setup();
        g_ops[ue] = PeekPointer(ops);
        tsb->SetCongestionControlAlgorithm(ops);
    }
    tsb->TraceConnectWithoutContext("RTT", MakeBoundCallback(&RttCb, ue));
    tsb->TraceConnectWithoutContext("CongestionWindow", MakeBoundCallback(&CwndCb, ue));
}

void
UpdateDoppler(Ptr<Node> ue, uint32_t idx, double fc)
{
    Ptr<MobilityModel> m = ue->GetObject<MobilityModel>();
    double v = m->GetVelocity().GetLength();
    g_chan[idx].doppler = v * fc / 3e8;
    Simulator::Schedule(MilliSeconds(50), &UpdateDoppler, ue, idx, fc);
}

void
CalibSample(uint32_t ue, Ptr<Node> node)
{
    if (!g_rtt[ue].empty() && g_calibFile.is_open())
    {
        Chan& c = g_chan[ue];
        g_calibFile << ue << ' ' << Simulator::Now().GetSeconds() << ' ' << c.rsrp << ' ' << c.sinr << ' '
                    << c.doppler << ' ' << g_rtt[ue].back() << '\n';
    }
    Simulator::Schedule(MilliSeconds(50), &CalibSample, ue, node);
}

int
main(int argc, char* argv[])
{
    CommandLine cmd(__FILE__);
    cmd.AddValue("ueCols", "UE antenna columns", g_cfg.ueCols);
    cmd.AddValue("rlc", "RlcUmAlways|RlcAmAlways", g_cfg.rlcMode);
    cmd.AddValue("chCond", "Default|LOS|NLOS", g_cfg.chCond);
    cmd.AddValue("hoMode", "a3|geo", g_cfg.hoMode);
    cmd.AddValue("hoOff", "geo-mode handover offset past midpoint (m)", g_cfg.hoOff);
    cmd.AddValue("a3Hys", "A3 hysteresis dB", g_cfg.a3Hys);
    cmd.AddValue("a3Ttt", "A3 time-to-trigger ms", g_cfg.a3TttMs);
    cmd.AddValue("variant", "newreno|cubic|bbr|westwood|ppo|nc_full|nc_notasi|nc_nodrtd|nc_noamabcs", g_cfg.variant);
    cmd.AddValue("policy", "actor weights file", g_cfg.policyFile);
    cmd.AddValue("imprint", "TASI imprint file", g_cfg.imprintFile);
    cmd.AddValue("chan", "DRTD-CD f() weights file", g_cfg.chanFile);
    cmd.AddValue("traj", "trajectory log (training)", g_cfg.trajFile);
    cmd.AddValue("stochastic", "sample actions", g_cfg.stochastic);
    cmd.AddValue("simTime", "simulation time (s)", g_cfg.simTime);
    cmd.AddValue("ueNum", "UEs", g_cfg.ueNum);
    cmd.AddValue("diag", "diag", g_diag);
    cmd.AddValue("diagNoLoad", "diag", g_diagNoLoad);
    cmd.AddValue("gnbNum", "gNBs", g_cfg.gnbNum);
    cmd.AddValue("isd", "inter-site distance", g_cfg.isd);
    cmd.AddValue("seed", "RNG run", g_cfg.seed);
    cmd.AddValue("out", "output prefix", g_cfg.outPrefix);
    cmd.AddValue("calib", "light-load calibration mode (DRTD-CD f data)", g_cfg.calib);
    cmd.Parse(argc, argv);

    Config::SetDefault("ns3::NrGnbRrc::EpsBearerToRlcMapping", StringValue(g_cfg.rlcMode));
    Config::SetDefault("ns3::NrRlcAm::MaxTxBufferSize", UintegerValue(1024 * 1024));
    Config::SetDefault("ns3::NrRlcUm::MaxTxBufferSize", UintegerValue(1024 * 1024));
    RngSeedManager::SetSeed(7);
    RngSeedManager::SetRun(g_cfg.seed);

    std::string tcpType = "ns3::TcpNewReno";
    if (g_cfg.variant == "cubic") tcpType = "ns3::TcpCubic";
    if (g_cfg.variant == "bbr") tcpType = "ns3::TcpBbr";
    if (g_cfg.variant == "westwood") tcpType = "ns3::TcpWestwoodPlus";
    Config::SetDefault("ns3::TcpL4Protocol::SocketType", StringValue(tcpType));
    Config::SetDefault("ns3::TcpSocket::SegmentSize", UintegerValue(1448));
    Config::SetDefault("ns3::TcpSocket::SndBufSize", UintegerValue(8 * 1024 * 1024));
    Config::SetDefault("ns3::TcpSocket::RcvBufSize", UintegerValue(8 * 1024 * 1024));

    const uint32_t U = g_cfg.ueNum, G = g_cfg.gnbNum;
    g_chan.assign(U, Chan());
    g_ops.assign(U, nullptr);
    g_goodBins.assign(U, {});
    g_rtt.assign(U, {});
    g_cwnd.assign(U, {});

    double fc = 3.5e9, bw = 40e6;

    // nodes + positions
    NodeContainer gnbNodes, ueNodes;
    gnbNodes.Create(G);
    ueNodes.Create(U);
    Ptr<ListPositionAllocator> gpos = CreateObject<ListPositionAllocator>();
    for (uint32_t g = 0; g < G; g++)
    {
        gpos->Add(Vector(g * g_cfg.isd, 0.0, 25.0));
    }
    MobilityHelper gm;
    gm.SetMobilityModel("ns3::ConstantPositionMobilityModel");
    gm.SetPositionAllocator(gpos);
    gm.Install(gnbNodes);

    Ptr<UniformRandomVariable> rv = CreateObject<UniformRandomVariable>();
    rv->SetStream(900 + g_cfg.seed);
    std::vector<double> x0(U), vx(U), yy(U);
    MobilityHelper um;
    um.SetMobilityModel("ns3::ConstantVelocityMobilityModel");
    um.Install(ueNodes);
    for (uint32_t u = 0; u < U; u++)
    {
        x0[u] = rv->GetValue(-40.0, 40.0);
        vx[u] = g_cfg.calib ? rv->GetValue(3.0, 33.0) : rv->GetValue(15.0, 33.0);
        yy[u] = rv->GetValue(10.0, 30.0);
        Ptr<ConstantVelocityMobilityModel> m = ueNodes.Get(u)->GetObject<ConstantVelocityMobilityModel>();
        m->SetPosition(Vector(x0[u], yy[u], 1.5));
        m->SetVelocity(Vector(vx[u], 0, 0));
    }

    // NR
    Ptr<NrPointToPointEpcHelper> epc = CreateObject<NrPointToPointEpcHelper>();
    Ptr<IdealBeamformingHelper> bf = CreateObject<IdealBeamformingHelper>();
    Ptr<NrHelper> nr = CreateObject<NrHelper>();
    nr->SetBeamformingHelper(bf);
    nr->SetEpcHelper(epc);
    if (g_cfg.hoMode == "a3")
    {
        nr->SetHandoverAlgorithmType("ns3::NrA3RsrpHandoverAlgorithm");
        nr->SetHandoverAlgorithmAttribute("Hysteresis", DoubleValue(g_cfg.a3Hys));
        nr->SetHandoverAlgorithmAttribute("TimeToTrigger", TimeValue(MilliSeconds(g_cfg.a3TttMs)));
    }
    else
    {
        nr->SetHandoverAlgorithmType("ns3::NrNoOpHandoverAlgorithm");
    }
    Ptr<NrChannelHelper> ch = CreateObject<NrChannelHelper>();
    ch->ConfigureFactories("UMa", g_cfg.chCond, "ThreeGpp");
    if (g_cfg.chCond == "Default")
    {
        ch->SetChannelConditionModelAttribute("UpdatePeriod", TimeValue(MilliSeconds(0)));
    }
    ch->SetPathlossAttribute("ShadowingEnabled", BooleanValue(true));
    // single shared carrier: the NR UE RRC re-synchronises its primary PHY to the target cell, so
    // handover is intra-frequency
    CcBwpCreator ccc;
    CcBwpCreator::SimpleOperationBandConf bc(fc, bw, 1);
    OperationBandInfo band = ccc.CreateOperationBandContiguousCc(bc);
    ch->AssignChannelsToBands({band});
    BandwidthPartInfoPtrVector bwps = CcBwpCreator::GetAllBwps({band});
    std::vector<BandwidthPartInfoPtrVector> gnbBwps(G, bwps);
    BandwidthPartInfoPtrVector allBwps = bwps;
    bf->SetAttribute("BeamformingMethod", TypeIdValue(DirectPathBeamforming::GetTypeId()));
    nr->SetUeAntennaAttribute("NumRows", UintegerValue(1));
    nr->SetUeAntennaAttribute("NumColumns", UintegerValue(g_cfg.ueCols));
    nr->SetUeAntennaAttribute("AntennaElement", PointerValue(CreateObject<IsotropicAntennaModel>()));
    nr->SetGnbAntennaAttribute("NumRows", UintegerValue(4));
    nr->SetGnbAntennaAttribute("NumColumns", UintegerValue(4));
    nr->SetGnbAntennaAttribute("AntennaElement", PointerValue(CreateObject<IsotropicAntennaModel>()));
    NetDeviceContainer gnbDev;
    for (uint32_t g = 0; g < G; g++)
    {
        gnbDev.Add(nr->InstallGnbDevice(gnbNodes.Get(g), gnbBwps[g]));
    }
    // NrHelper (v4.1.1) never instantiates the handover algorithm, so wire the A3-RSRP algorithm to each
    // gNB RRC here (as LteHelper does): measurement-based handover instead of scripted instants.
    static std::vector<Ptr<NrHandoverAlgorithm>> s_hoAlgs;
    if (g_cfg.hoMode == "a3")
    {
        for (uint32_t g = 0; g < G; g++)
        {
            Ptr<NrGnbRrc> rrc = gnbDev.Get(g)->GetObject<NrGnbNetDevice>()->GetRrc();
            Ptr<NrA3RsrpHandoverAlgorithm> alg = CreateObjectWithAttributes<NrA3RsrpHandoverAlgorithm>(
                "Hysteresis", DoubleValue(g_cfg.a3Hys), "TimeToTrigger", TimeValue(MilliSeconds(g_cfg.a3TttMs)));
            alg->SetNrHandoverManagementSapUser(rrc->GetNrHandoverManagementSapUser());
            rrc->SetNrHandoverManagementSapProvider(alg->GetNrHandoverManagementSapProvider());
            alg->Initialize();
            s_hoAlgs.push_back(alg);
        }
    }
    NetDeviceContainer ueDev = nr->InstallUeDevice(ueNodes, allBwps);
    int64_t stream = 1;
    stream += nr->AssignStreams(gnbDev, stream);
    stream += nr->AssignStreams(ueDev, stream);
    for (uint32_t i = 0; i < gnbDev.GetN(); i++)
    {
        NrHelper::GetGnbPhy(gnbDev.Get(i), 0)->SetAttribute("Numerology", UintegerValue(1));
        NrHelper::GetGnbPhy(gnbDev.Get(i), 0)->SetTxPower(40);
    }

    for (uint32_t i = 0; i < ueDev.GetN(); i++)
    {
        NrHelper::GetUePhy(ueDev.Get(i), 0)->SetTxPower(23); // standard UE power class 3 (default is 2 dBm)
    }

    // internet
    Ptr<Node> pgw = epc->GetPgwNode();
    NodeContainer rh;
    rh.Create(1);
    InternetStackHelper inet;
    inet.Install(rh);
    PointToPointHelper p2p;
    p2p.SetDeviceAttribute("DataRate", DataRateValue(DataRate("10Gb/s")));
    p2p.SetDeviceAttribute("Mtu", UintegerValue(1500));
    p2p.SetChannelAttribute("Delay", TimeValue(MilliSeconds(5)));
    NetDeviceContainer idev = p2p.Install(pgw, rh.Get(0));
    Ipv4AddressHelper ip;
    ip.SetBase("1.0.0.0", "255.0.0.0");
    ip.Assign(idev);
    Ipv4StaticRoutingHelper srh;
    Ptr<Ipv4StaticRouting> rhr = srh.GetStaticRouting(rh.Get(0)->GetObject<Ipv4>());
    rhr->AddNetworkRouteTo(Ipv4Address("7.0.0.0"), Ipv4Mask("255.0.0.0"), 1);
    inet.Install(ueNodes);
    Ipv4InterfaceContainer ueIf = epc->AssignUeIpv4Address(NetDeviceContainer(ueDev));
    for (uint32_t j = 0; j < U; j++)
    {
        Ptr<Ipv4StaticRouting> r = srh.GetStaticRouting(ueNodes.Get(j)->GetObject<Ipv4>());
        r->SetDefaultRoute(epc->GetUeDefaultGatewayAddress(), 1);
    }

    // initial attach to nearest gNB, then X2 + scheduled handovers at cell boundaries
    std::vector<uint32_t> cur(U);
    for (uint32_t u = 0; u < U; u++)
    {
        uint32_t best = (uint32_t)std::max(0.0, std::min<double>(G - 1, std::round(x0[u] / g_cfg.isd)));
        cur[u] = best;
        nr->AttachToGnb(ueDev.Get(u), gnbDev.Get(best));
        g_nodeToUe[ueNodes.Get(u)->GetId()] = u;
    }
    nr->AddX2Interface(gnbNodes);
    // beamforming vectors are only computed for registered (gNB, UE) pairs; AttachToGnb registers just the
    // initial serving pair, so register all remaining pairs so that a handover target can serve the UE
    for (uint32_t u = 0; u < U; u++)
    {
        for (uint32_t c = 0; c < G; c++)
        {
            if (c != cur[u])
            {
                // the target gNB PHY resolves the beam of a scheduled RNTI through its registered UE devices
                gnbDev.Get(c)->GetObject<NrGnbNetDevice>()->GetPhy(0)->RegisterUe(
                    ueDev.Get(u)->GetObject<NrUeNetDevice>()->GetImsi(), ueDev.Get(u)->GetObject<NrUeNetDevice>());
                // after initial attach (UE cell id set), so that candidate tasks only store vectors
                Simulator::Schedule(Seconds(0.05), &IdealBeamformingHelper::AddBeamformingTask, bf,
                                    gnbDev.Get(c)->GetObject<NrGnbNetDevice>(), ueDev.Get(u)->GetObject<NrUeNetDevice>());
            }
        }
    }
    for (uint32_t u = 0; u < U; u++)
    {
        uint32_t c = cur[u];
        while (c + 1 < G)
        {
            double xb = (c + 0.5) * g_cfg.isd + g_cfg.hoOff;
            double t = (xb - x0[u]) / vx[u];
            if (g_cfg.hoMode == "geo" && t > 0.3 && t < g_cfg.simTime - 0.5)
            {
                nr->HandoverRequest(Seconds(t), ueDev.Get(u), gnbDev.Get(c), gnbDev.Get(c + 1));
            }
            c++;
        }
    }

    // traces
    Config::Connect("/NodeList/*/DeviceList/*/$ns3::NrUeNetDevice/ComponentCarrierMapUe/*/NrUePhy/ReportUeMeasurements",
                    MakeCallback(&OnMeas));
    Config::Connect("/NodeList/*/DeviceList/*/$ns3::NrUeNetDevice/ComponentCarrierMapUe/*/NrUePhy/DlDataSinr",
                    MakeCallback(&OnSinr));
    Config::Connect("/NodeList/*/DeviceList/*/$ns3::NrUeNetDevice/NrUeRrc/HandoverEndOk", MakeCallback(&OnHoEnd));
    for (uint32_t u = 0; u < U; u++)
    {
        UpdateDoppler(ueNodes.Get(u), u, fc);
    }

    if (g_diag) {
        Config::Connect("/NodeList/*/DeviceList/*/$ns3::NrUeNetDevice/NrUeRrc/StateTransition", MakeCallback(&DiagUeSt));
        Config::Connect("/NodeList/*/DeviceList/*/$ns3::NrGnbNetDevice/NrGnbRrc/RrcTimeout", MakeCallback(&DiagTmo));
    }
    if (g_diag) Config::Connect("/NodeList/*/ApplicationList/*/$ns3::NrEpcGnbApplication/RxFromS1u", MakeCallback(&DiagS1u));
    if (g_diag) Config::Connect("/NodeList/*/DeviceList/*/$ns3::NrUeNetDevice/ComponentCarrierMapUe/*/NrUePhy/ReportUeMeasurements", MakeCallback(&DiagMeas));
    if (g_diag) Config::Connect("/NodeList/*/DeviceList/*/$ns3::NrUeNetDevice/ComponentCarrierMapUe/*/NrUePhy/DlDataSinr", MakeCallback(&DiagSinr));
    if (g_diag) Config::Connect("/NodeList/*/DeviceList/*/$ns3::NrUeNetDevice/ComponentCarrierMapUe/*/NrUePhy/UePhyRxedCtrlMsgsTrace", MakeCallback(&DiagCtrl));
    if (g_diag) { Config::Connect("/NodeList/*/$ns3::Ipv4L3Protocol/Rx", MakeCallback(&DiagIpRx)); Config::Connect("/NodeList/*/$ns3::Ipv4L3Protocol/Drop", MakeCallback(&DiagIpDrop)); }
    if (g_diag) { Simulator::Schedule(Seconds(0.3), &DiagConnectUe); for (uint32_t u2=0;u2<U;u2++) for (uint32_t c2=0;c2+1<G;c2++){ double xb=(c2+0.5)*g_cfg.isd; double t2=(xb-x0[u2])/vx[u2]+0.01; if (t2>0.3 && t2<g_cfg.simTime-0.5) { Simulator::Schedule(Seconds(t2), &DiagConnectGnb); Simulator::Schedule(Seconds(t2), &DiagConnectUe); } } }
    // apps
    std::vector<Ptr<BulkSendApplication>> bulk;
    ApplicationContainer sinks;
    for (uint32_t u = 0; u < U; u++)
    {
        uint16_t port = 5000 + u;
        PacketSinkHelper sh("ns3::TcpSocketFactory", InetSocketAddress(Ipv4Address::GetAny(), port));
        ApplicationContainer sa = sh.Install(ueNodes.Get(u));
        sa.Start(Seconds(0.3));
        sa.Stop(Seconds(g_cfg.simTime));
        Ptr<PacketSink> psink = DynamicCast<PacketSink>(sa.Get(0));
        psink->TraceConnectWithoutContext("Rx", MakeBoundCallback(&SinkRx, u));
        if (g_cfg.calib)
        {
            OnOffHelper oh("ns3::TcpSocketFactory", InetSocketAddress(ueIf.GetAddress(u), port));
            oh.SetAttribute("DataRate", DataRateValue(DataRate("300kb/s")));
            oh.SetAttribute("PacketSize", UintegerValue(200));
            oh.SetAttribute("OnTime", StringValue("ns3::ConstantRandomVariable[Constant=1000]"));
            oh.SetAttribute("OffTime", StringValue("ns3::ConstantRandomVariable[Constant=0]"));
            ApplicationContainer oa = oh.Install(rh.Get(0));
            oa.Start(Seconds(0.5));
            oa.Stop(Seconds(g_cfg.simTime - 0.2));
            Ptr<OnOffApplication> oapp = DynamicCast<OnOffApplication>(oa.Get(0));
            Simulator::Schedule(Seconds(0.502), [u, oapp]() {
                Ptr<TcpSocketBase> tsb = DynamicCast<TcpSocketBase>(oapp->GetSocket());
                if (tsb) tsb->TraceConnectWithoutContext("RTT", MakeBoundCallback(&RttCb, u));
            });
            Simulator::Schedule(Seconds(1.0), &CalibSample, u, ueNodes.Get(u));
        }
        else if (g_diagNoLoad && u >= 1)
        {
            // diagnostic: no traffic for UEs >= 1
        }
        else
        {
            BulkSendHelper bh("ns3::TcpSocketFactory", InetSocketAddress(ueIf.GetAddress(u), port));
            bh.SetAttribute("MaxBytes", UintegerValue(0));
            ApplicationContainer ba = bh.Install(rh.Get(0));
            double st = 0.5 + 0.05 * u;
            ba.Start(Seconds(st));
            ba.Stop(Seconds(g_cfg.simTime - 0.2));
            Ptr<BulkSendApplication> bapp = DynamicCast<BulkSendApplication>(ba.Get(0));
            bulk.push_back(bapp);
            Simulator::Schedule(Seconds(st + 0.001), &AttachCc, u, bapp);
        }
    }

    if (!g_cfg.trajFile.empty())
    {
        g_trajOut.open(g_cfg.trajFile);
    }
    if (g_cfg.calib)
    {
        g_calibFile.open(g_cfg.outPrefix + "_calib.txt");
    }

    FlowMonitorHelper fmh;
    Ptr<FlowMonitor> mon = fmh.InstallAll();
    Simulator::Stop(Seconds(g_cfg.simTime));
    Simulator::Run();
    mon->CheckForLostPackets();
    if (g_diag) for (auto& k : g_sinrAcc) std::cerr << k.first << " meanSinr_dB=" << k.second.first/k.second.second << " n=" << k.second.second << "\n";
    if (g_diag) for (auto& k : g_ctrl) std::cerr << k.first << " = " << k.second << "\n";
    if (g_diag) for (auto& n : g_ip) { std::cerr << n.first << ":"; for (auto& b : n.second) std::cerr << ' ' << b.first/2.0 << '=' << b.second; std::cerr << "\n"; }
    if (g_diag) for (auto& n : g_rlc) { std::cerr << n.first << ":"; for (auto& b : n.second) std::cerr << ' ' << b.first/2.0 << '=' << b.second; std::cerr << "\n"; }
    if (g_diag) for (auto& n : g_s1u) { std::cerr << "node " << n.first << ":"; for (auto& b : n.second) std::cerr << ' ' << b.first/2.0 << '=' << b.second; std::cerr << "\n"; }

    uint64_t tx = 0, rx = 0;
    for (auto const& kv : mon->GetFlowStats())
    {
        // count only data direction (remote host -> UE) flows
        Ptr<Ipv4FlowClassifier> cl = DynamicCast<Ipv4FlowClassifier>(fmh.GetClassifier());
        Ipv4FlowClassifier::FiveTuple t = cl->FindFlow(kv.first);
        if (t.sourceAddress == Ipv4Address("1.0.0.2") || t.sourceAddress.Get() >> 24 == 1)
        {
            tx += kv.second.txPackets;
            rx += kv.second.rxPackets;
        }
    }

    // summary output
    std::ofstream out(g_cfg.outPrefix + "_summary.txt");
    out << std::fixed << std::setprecision(4);
    out << "variant " << g_cfg.variant << " seed " << g_cfg.seed << " simTime " << g_cfg.simTime << "\n";
    out << "pdr " << (tx ? 100.0 * rx / tx : 0.0) << "\n";
    out << "ovh " << g_decN << ' ' << (g_decN ? g_decNs / g_decN / 1000.0 : 0.0) << "\n";
    for (uint32_t u = 0; u < U; u++)
    {
        double bytes = 0;
        for (double b : g_goodBins[u]) bytes += b;
        double dur = g_cfg.simTime - 0.7;
        double rttMean = 0;
        for (double r : g_rtt[u]) rttMean += r;
        rttMean = g_rtt[u].empty() ? -1 : rttMean / g_rtt[u].size();
        double cm = 0, cv = 0;
        for (uint32_t c : g_cwnd[u]) cm += c;
        if (!g_cwnd[u].empty())
        {
            cm /= g_cwnd[u].size();
            for (uint32_t c : g_cwnd[u]) cv += (c - cm) * (c - cm);
            cv = std::sqrt(cv / g_cwnd[u].size()) / std::max(1.0, cm);
        }
        out << "ue " << u << " thr_mbps " << bytes * 8.0 / dur / 1e6 << " rtt_ms " << rttMean << " cwnd_cv " << cv
            << " ho";
        for (double t : g_hoTimes[u]) out << ' ' << t;
        out << "\n";
    }
    for (uint32_t u = 0; u < U; u++)
    {
        out << "bins " << u;
        for (double b : g_goodBins[u]) out << ' ' << b;
        out << "\n";
    }
    for (uint32_t u = 0; u < U; u++)
    {
        out << "hox " << u << ' ' << x0[u] << ' ' << vx[u] << "\n";
    }
    out.close();
    if (g_trajOut.is_open()) g_trajOut.close();
    if (g_calibFile.is_open()) g_calibFile.close();
    Simulator::Destroy();
    return 0;
}
