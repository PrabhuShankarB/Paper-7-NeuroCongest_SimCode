# NeuroCongest: executed packet-level evaluation (ns-3 3.46 + 5G-LENA NR v4.1.1)

This package replaces the earlier Monte Carlo material. Every number in the revised manuscript comes from the runs recorded here.

## Contents
- `experiment/neurocongest-exp.cc` - ns-3 scenario and all controllers (NewReno, CUBIC, BBR, Westwood+, Vegas, Illinois, YeAH, HighSpeed, Veno, H-TCP, BIC, Hybla, plain PPO, NeuroCongest and the ablations nc_notasi / nc_nodrtd / nc_noamabcs).
- `ns3_patch/nr_v4.1.1_handover_fixes.patch` - robustness patches to the NR module (SR-state watchdog, released-UE guards in the scheduler, non-fatal RX collisions at handover, stale-RNTI drops, beamforming re-pointing after synchronization). They apply to every variant equally; their effect on absolute values is not quantified.
- `harness/` - numpy PPO (`nc_lib.py`, `train.py`), evaluation (`eval.py`, `run_more.py`, `run_scen.py`), DRTD-CD calibration and fit (`calib.py`, `fit_drtd.py`), statistics (`analyze.py`), figures (`make_figs.py`), decision-timing check (`ovh.py`).
- `policies/` - trained actor weights, TASI imprints, DRTD-CD delay model and its fit statistics.
- `results/per_run_metrics.csv` - one row per run (460 runs: 17 controllers x 20 seeds in the base scenario; 6 controllers x 10 seeds in each of the load and NLOS scenarios). `results.json` holds means, bootstrap intervals, paired differences and Wilcoxon p-values. `train_*.log` are the training logs.
- `figures/` - the black-and-white figures used in the manuscript.

## Setup
Scenario: 3 gNBs 200 m apart, 3.5 GHz, 40 MHz, UMa (TR 38.901), X2 handover triggered geometrically at the cell-boundary midpoint + 40 m, RLC UM, 4 UEs at 15-33 m/s (8 in the load scenario, NLOS forced in the NLOS scenario), 16 s runs. Training seeds 1-100; evaluation seeds 201-220 (201-210 for the load and NLOS scenarios). Re-running a seed reproduces its run exactly.

## Reproduce
1. Build ns-3 3.46 with NR v4.1.1 and apply `ns3_patch/nr_v4.1.1_handover_fixes.patch`; copy `experiment/neurocongest-exp.cc` into `contrib/nr/examples/` and build.
2. Train: `python3 harness/train.py ppo 20 6`, `python3 harness/train.py nc_full 20 6 5`, and likewise `nc_nodrtd`, `nc_noamabcs`. DRTD-CD calibration: `calib.py`, then `fit_drtd.py`.
3. Evaluate: `eval.py`, `run_more.py` (extra classical variants), `run_scen.py` (scenarios). Aggregate: `analyze.py`. Figures: `make_figs.py`. Paths inside the scripts point to the working directory used for the study and must be adapted.

## What this package does not contain
Orca and TCP-DrINC were not implemented. The plain PPO controller is Orca-style, not Orca. There is no mmWave, LEO or heterogeneous-cell scenario. The evaluated TASI, AMABCS and DRTD-CD are simplified relative to the design (manuscript Table 4). One policy was trained per variant.
