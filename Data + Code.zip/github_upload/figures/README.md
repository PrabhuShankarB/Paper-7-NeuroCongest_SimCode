Figures regenerated from data/ CSVs using matplotlib (code available on request; not included here as execution files per the upload scope).
