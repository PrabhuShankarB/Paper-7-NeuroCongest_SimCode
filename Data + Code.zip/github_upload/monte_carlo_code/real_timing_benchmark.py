"""
Real Timing Micro-Benchmark (Not Monte Carlo, Not NS-3)
==========================================================
This measures bare arithmetic operations in isolation on whatever CPU
executes this script. It is real, executed Python/NumPy timing, but it
is NOT the ARM Cortex-A55 embedded target referenced elsewhere as the
deployment hardware, and does not include framework/OS overhead.
"""

import time
import platform
import subprocess
import numpy as np

N_TRIALS = 10000


def get_cpu_info():
    info = {"machine": platform.machine(), "processor": platform.processor()}
    try:
        cpuinfo = subprocess.run(["grep", "model name", "/proc/cpuinfo"], capture_output=True, text=True).stdout
        if cpuinfo:
            info["model"] = cpuinfo.split("\n")[0].split(":")[-1].strip()
    except Exception:
        info["model"] = "unavailable"
    return info


def time_tasi_restoration(d=512, n_trials=N_TRIALS):
    theta_base = np.random.randn(d).astype(np.float32)
    delta_theta = np.random.randn(d).astype(np.float32)
    t0 = time.perf_counter()
    for _ in range(n_trials):
        theta_active = theta_base + delta_theta
    t1 = time.perf_counter()
    return (t1 - t0) / n_trials * 1000


def time_drtdcd_forward(n_trials=N_TRIALS):
    W1 = np.random.randn(3, 16).astype(np.float32)
    b1 = np.random.randn(16).astype(np.float32)
    W2 = np.random.randn(16, 2).astype(np.float32)
    b2 = np.random.randn(2).astype(np.float32)
    x = np.random.randn(3).astype(np.float32)
    t0 = time.perf_counter()
    for _ in range(n_trials):
        h = np.maximum(0, x @ W1 + b1)
        out = h @ W2 + b2
    t1 = time.perf_counter()
    return (t1 - t0) / n_trials * 1000


def time_amabcs_arm_eval(K=7, n_trials=N_TRIALS):
    arm_features = np.random.randn(K, 4).astype(np.float32)
    weights = np.random.randn(4).astype(np.float32)
    t0 = time.perf_counter()
    for _ in range(n_trials):
        scores = arm_features @ weights
        best = np.argmax(scores)
    t1 = time.perf_counter()
    return (t1 - t0) / n_trials * 1000


if __name__ == "__main__":
    print("=" * 70)
    print("Real Timing Benchmark (executed, not simulated)")
    print("=" * 70)
    cpu_info = get_cpu_info()
    print(f"Hardware: {cpu_info}")
    print("NOTE: x86 development machine, NOT ARM Cortex-A55 target hardware.")
    print()

    tasi_ms = time_tasi_restoration()
    drtd_ms = time_drtdcd_forward()
    amabcs_ms = time_amabcs_arm_eval()
    total_ms = tasi_ms + drtd_ms + amabcs_ms

    print(f"TASI restoration (d=512):        {tasi_ms:.6f} ms")
    print(f"DRTD-CD forward pass:             {drtd_ms:.6f} ms")
    print(f"AMABCS K=7 arm evaluation:        {amabcs_ms:.6f} ms")
    print(f"Total (excl. PPO inference):      {total_ms:.6f} ms")
    print()
    print(f"Trials per operation: {N_TRIALS}")
