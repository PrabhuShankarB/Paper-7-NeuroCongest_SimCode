"""
NeuroCongest Monte Carlo Simulation and Statistical Validation
================================================================

HONEST SCOPE STATEMENT (read this before using this code or its output):

This script does NOT run NS-3 or any packet-level network simulator.
It implements a Monte Carlo model in which each protocol's performance
on each metric is represented by an assumed mean and standard deviation,
calibrated by the authors based on each protocol's known behavior class
(reactive loss-based, model-based, wireless-aware heuristic, or
anticipatory/causal). Random samples are drawn from those assumed
distributions using NumPy, and statistical tests (Wilcoxon signed-rank)
are computed on the real sampled data using SciPy.

See ns3_simulation/ in this repository for the one real, executed
packet-level data point produced by actual NS-3 + 5G-LENA simulation.

Usage:
    python3 run_simulation.py
Output:
    Writes one CSV per table to ../data/
"""

import numpy as np
import pandas as pd
from scipy import stats
import os

OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
os.makedirs(OUT_DIR, exist_ok=True)

N_RUNS = 30

MAIN_PROTOCOLS = {
    "NewReno":      dict(rtt=(1.058, 0.020), thr=(56.78, 1.48), pdr=(93.94, 0.42), cwnd_cv=(0.425, 0.015), ho=(264.0, 8.3)),
    "CUBIC":        dict(rtt=(0.864, 0.020), thr=(70.83, 1.91), pdr=(95.53, 0.34), cwnd_cv=(0.350, 0.011), ho=(229.1, 6.3)),
    "BBR":          dict(rtt=(0.698, 0.013), thr=(78.52, 1.02), pdr=(96.87, 0.22), cwnd_cv=(0.277, 0.014), ho=(202.1, 6.9)),
    "Westwood+":    dict(rtt=(0.658, 0.014), thr=(81.96, 1.48), pdr=(97.24, 0.21), cwnd_cv=(0.245, 0.013), ho=(187.6, 4.5)),
    "DQN-TCP":      dict(rtt=(0.521, 0.009), thr=(81.4, 1.3),   pdr=(97.90, 0.18), cwnd_cv=(0.168, 0.009), ho=(63.2, 3.8)),
    "Orca":         dict(rtt=(0.498, 0.008), thr=(84.1, 1.2),   pdr=(98.20, 0.16), cwnd_cv=(0.151, 0.008), ho=(58.7, 3.4)),
    "TCP-DrINC":    dict(rtt=(0.509, 0.008), thr=(82.6, 1.2),   pdr=(98.00, 0.17), cwnd_cv=(0.159, 0.008), ho=(61.0, 3.6)),
    "NeuroCongest": dict(rtt=(0.410, 0.008), thr=(96.29, 1.22), pdr=(99.12, 0.12), cwnd_cv=(0.094, 0.005), ho=(1.12, 0.04)),
}
METRIC_KEYS = ["rtt", "thr", "pdr", "cwnd_cv", "ho"]


def sample(mu_sd, n=N_RUNS, seed=1):
    mu, sd = mu_sd
    rng = np.random.default_rng(seed)
    return np.clip(rng.normal(mu, sd, size=n), 0.0001, None)


def summarize(arr):
    m = arr.mean()
    ci = 1.96 * arr.std(ddof=1) / np.sqrt(len(arr))
    return round(float(m), 3), round(float(ci), 3)


def build_table4():
    results = {}
    for i, (p, params) in enumerate(MAIN_PROTOCOLS.items()):
        results[p] = {k: sample(params[k], seed=1000 + i * 10 + j) for j, k in enumerate(METRIC_KEYS)}
    rows = []
    for p in MAIN_PROTOCOLS:
        row = {"Protocol": p}
        for k in METRIC_KEYS:
            m, ci = summarize(results[p][k])
            row[f"{k}_mean"] = m
            row[f"{k}_ci95"] = ci
        rows.append(row)
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(OUT_DIR, "table4_overall_performance.csv"), index=False)
    print(df.to_string(index=False))
    return results


def build_significance(main_results):
    rows = []
    for baseline in ["NewReno", "CUBIC", "BBR", "Westwood+", "DQN-TCP", "Orca", "TCP-DrINC"]:
        for k in METRIC_KEYS:
            a = main_results[baseline][k]
            b = main_results["NeuroCongest"][k]
            try:
                stat, p = stats.wilcoxon(a, b)
            except ValueError:
                stat, p = float("nan"), float("nan")
            rows.append({"Baseline": baseline, "Metric": k, "W": round(float(stat), 3), "p_value": p})
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(OUT_DIR, "table12_wilcoxon_significance.csv"), index=False)
    print("\n=== Wilcoxon significance (sample) ===")
    print(df.head(10).to_string(index=False))


if __name__ == "__main__":
    print("=" * 70)
    print("NeuroCongest Monte Carlo Simulation")
    print("SCOPE: assumed per-protocol distributions, NOT executed NS-3 output")
    print("=" * 70)
    print()
    print("Table 4: Overall Performance Comparison (mean +/- 95% CI, 30 runs)")
    print("-" * 70)
    main_results = build_table4()
    build_significance(main_results)
    print()
    print("Done. CSVs written to ../data/")
