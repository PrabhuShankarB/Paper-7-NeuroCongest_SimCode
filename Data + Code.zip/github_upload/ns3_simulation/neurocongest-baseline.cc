// NeuroCongest baseline validation: real NS-3 + 5G-LENA simulation
// Single macro gNB, multiple UEs, TCP bulk transfer, FlowMonitor stats.
// This is a REAL executed simulation, not a Monte Carlo model.

#include "ns3/antenna-module.h"
#include "ns3/applications-module.h"
#include "ns3/config-store.h"
#include "ns3/core-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/internet-module.h"
#include "ns3/mobility-module.h"
#include "ns3/network-module.h"
#include "ns3/nr-module.h"
#include "ns3/point-to-point-module.h"

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("NeuroCongestBaseline");

int
main(int argc, char* argv[])
{
    // ---- Configurable parameters ----
    std::string tcpVariant = "ns3::TcpNewReno";
    uint16_t gNbNum = 1;
    uint16_t ueNumPergNb = 4;
    double simTime = 10.0;       // seconds
    double centralFrequencyBand1 = 3.5e9;  // macro cell, sub-6 GHz
    double bandwidthBand1 = 100e6;
    uint32_t tcpPayloadSize = 1448;

    CommandLine cmd(__FILE__);
    cmd.AddValue("tcpVariant", "TCP variant: ns3::TcpNewReno, ns3::TcpCubic, ns3::TcpBbr, ns3::TcpWestwoodPlus", tcpVariant);
    cmd.AddValue("ueNum", "Number of UEs", ueNumPergNb);
    cmd.AddValue("simTime", "Simulation time (s)", simTime);
    cmd.Parse(argc, argv);

    Config::SetDefault("ns3::TcpL4Protocol::SocketType", StringValue(tcpVariant));
    Config::SetDefault("ns3::TcpSocket::SegmentSize", UintegerValue(tcpPayloadSize));

    int64_t randomStream = 1;

    // ---- Radio scenario ----
    GridScenarioHelper gridScenario;
    gridScenario.SetRows(1);
    gridScenario.SetColumns(gNbNum);
    gridScenario.SetHorizontalBsDistance(500.0);  // macro cell spacing, matches paper's ~500m radius
    gridScenario.SetBsHeight(25.0);
    gridScenario.SetUtHeight(1.5);
    gridScenario.SetSectorization(GridScenarioHelper::SINGLE);
    gridScenario.SetBsNumber(gNbNum);
    gridScenario.SetUtNumber(ueNumPergNb * gNbNum);
    gridScenario.SetScenarioHeight(500);
    gridScenario.SetScenarioLength(500);
    randomStream += gridScenario.AssignStreams(randomStream);
    gridScenario.CreateScenario();

    Ptr<NrPointToPointEpcHelper> nrEpcHelper = CreateObject<NrPointToPointEpcHelper>();
    Ptr<IdealBeamformingHelper> idealBeamformingHelper = CreateObject<IdealBeamformingHelper>();
    Ptr<NrHelper> nrHelper = CreateObject<NrHelper>();
    Ptr<NrChannelHelper> channelHelper = CreateObject<NrChannelHelper>();

    nrHelper->SetBeamformingHelper(idealBeamformingHelper);
    nrHelper->SetEpcHelper(nrEpcHelper);

    channelHelper->ConfigureFactories("UMa", "Default", "ThreeGpp");  // Urban Macro, matches paper Section 5.4
    Config::SetDefault("ns3::ThreeGppChannelModel::UpdatePeriod", TimeValue(MilliSeconds(100)));
    channelHelper->SetChannelConditionModelAttribute("UpdatePeriod", TimeValue(MilliSeconds(0)));
    channelHelper->SetPathlossAttribute("ShadowingEnabled", BooleanValue(true));

    BandwidthPartInfoPtrVector allBwps;
    CcBwpCreator ccBwpCreator;
    const uint8_t numCcPerBand = 1;
    CcBwpCreator::SimpleOperationBandConf bandConf1(centralFrequencyBand1, bandwidthBand1, numCcPerBand);
    OperationBandInfo band1 = ccBwpCreator.CreateOperationBandContiguousCc(bandConf1);
    channelHelper->AssignChannelsToBands({band1});
    allBwps = CcBwpCreator::GetAllBwps({band1});

    idealBeamformingHelper->SetAttribute("BeamformingMethod", TypeIdValue(DirectPathBeamforming::GetTypeId()));

    nrHelper->SetUeAntennaAttribute("NumRows", UintegerValue(2));
    nrHelper->SetUeAntennaAttribute("NumColumns", UintegerValue(4));
    nrHelper->SetUeAntennaAttribute("AntennaElement", PointerValue(CreateObject<IsotropicAntennaModel>()));

    nrHelper->SetGnbAntennaAttribute("NumRows", UintegerValue(4));
    nrHelper->SetGnbAntennaAttribute("NumColumns", UintegerValue(8));
    nrHelper->SetGnbAntennaAttribute("AntennaElement", PointerValue(CreateObject<IsotropicAntennaModel>()));

    NetDeviceContainer gnbNetDev = nrHelper->InstallGnbDevice(gridScenario.GetBaseStations(), allBwps);
    NetDeviceContainer ueNetDev = nrHelper->InstallUeDevice(gridScenario.GetUserTerminals(), allBwps);

    randomStream += nrHelper->AssignStreams(gnbNetDev, randomStream);
    randomStream += nrHelper->AssignStreams(ueNetDev, randomStream);

    for (uint32_t i = 0; i < gnbNetDev.GetN(); i++)
    {
        NrHelper::GetGnbPhy(gnbNetDev.Get(i), 0)->SetAttribute("Numerology", UintegerValue(1));
        NrHelper::GetGnbPhy(gnbNetDev.Get(i), 0)->SetTxPower(43);
    }

    // ---- Internet / EPC remote host setup (standard ns-3 LTE/NR pattern) ----
    Ptr<Node> pgw = nrEpcHelper->GetPgwNode();

    NodeContainer remoteHostContainer;
    remoteHostContainer.Create(1);
    Ptr<Node> remoteHost = remoteHostContainer.Get(0);
    InternetStackHelper internet;
    internet.Install(remoteHostContainer);

    PointToPointHelper p2ph;
    p2ph.SetDeviceAttribute("DataRate", DataRateValue(DataRate("10Gb/s")));
    p2ph.SetDeviceAttribute("Mtu", UintegerValue(1500));
    p2ph.SetChannelAttribute("Delay", TimeValue(MilliSeconds(10)));  // core-network backhaul delay

    NetDeviceContainer internetDevices = p2ph.Install(pgw, remoteHost);
    Ipv4AddressHelper ipv4h;
    ipv4h.SetBase("1.0.0.0", "255.0.0.0");
    Ipv4InterfaceContainer internetIpIfaces = ipv4h.Assign(internetDevices);

    Ipv4StaticRoutingHelper ipv4RoutingHelper;
    Ptr<Ipv4StaticRouting> remoteHostStaticRouting =
        ipv4RoutingHelper.GetStaticRouting(remoteHost->GetObject<Ipv4>());
    remoteHostStaticRouting->AddNetworkRouteTo(Ipv4Address("7.0.0.0"), Ipv4Mask("255.0.0.0"), 1);

    internet.Install(gridScenario.GetUserTerminals());
    Ipv4InterfaceContainer ueIpIface = nrEpcHelper->AssignUeIpv4Address(NetDeviceContainer(ueNetDev));

    for (uint32_t j = 0; j < gridScenario.GetUserTerminals().GetN(); ++j)
    {
        Ptr<Node> ueNode = gridScenario.GetUserTerminals().Get(j);
        Ptr<Ipv4StaticRouting> ueStaticRouting =
            ipv4RoutingHelper.GetStaticRouting(ueNode->GetObject<Ipv4>());
        ueStaticRouting->SetDefaultRoute(nrEpcHelper->GetUeDefaultGatewayAddress(), 1);
    }

    nrHelper->AttachToClosestGnb(ueNetDev, gnbNetDev);

    // ---- Mobility: Random Waypoint, matching paper Section 5.3 ----
    MobilityHelper ueMobility;
    Ptr<PositionAllocator> positionAlloc =
        CreateObjectWithAttributes<RandomBoxPositionAllocator>(
            "X", StringValue("ns3::UniformRandomVariable[Min=0.0|Max=500.0]"),
            "Y", StringValue("ns3::UniformRandomVariable[Min=0.0|Max=500.0]"),
            "Z", StringValue("ns3::ConstantRandomVariable[Constant=1.5]"));
    ueMobility.SetPositionAllocator(positionAlloc);
    ueMobility.SetMobilityModel("ns3::RandomWaypointMobilityModel",
                                "Speed", StringValue("ns3::UniformRandomVariable[Min=1.0|Max=33.0]"), // ~3.6-120 km/h
                                "Pause", StringValue("ns3::ConstantRandomVariable[Constant=1.0]"),
                                "PositionAllocator", PointerValue(positionAlloc));
    ueMobility.Install(gridScenario.GetUserTerminals());

    // ---- TCP traffic: bulk send from remote host to each UE ----
    uint16_t basePort = 5000;
    ApplicationContainer sinkApps;
    ApplicationContainer sourceApps;

    for (uint32_t u = 0; u < ueNetDev.GetN(); ++u)
    {
        uint16_t port = basePort + u;
        PacketSinkHelper sinkHelper("ns3::TcpSocketFactory",
                                    InetSocketAddress(Ipv4Address::GetAny(), port));
        sinkApps.Add(sinkHelper.Install(gridScenario.GetUserTerminals().Get(u)));

        BulkSendHelper sourceHelper("ns3::TcpSocketFactory",
                                    InetSocketAddress(ueIpIface.GetAddress(u), port));
        sourceHelper.SetAttribute("MaxBytes", UintegerValue(0));  // unlimited, runs for simTime
        sourceApps.Add(sourceHelper.Install(remoteHost));
    }

    sinkApps.Start(Seconds(0.5));
    sinkApps.Stop(Seconds(simTime));
    sourceApps.Start(Seconds(1.0));
    sourceApps.Stop(Seconds(simTime - 0.5));

    // ---- FlowMonitor for real RTT/throughput/loss extraction ----
    FlowMonitorHelper flowmonHelper;
    Ptr<FlowMonitor> monitor = flowmonHelper.InstallAll();

    Simulator::Stop(Seconds(simTime));
    Simulator::Run();

    monitor->CheckForLostPackets();
    Ptr<Ipv4FlowClassifier> classifier =
        DynamicCast<Ipv4FlowClassifier>(flowmonHelper.GetClassifier());
    std::map<FlowId, FlowMonitor::FlowStats> stats = monitor->GetFlowStats();

    double totalDelaySum = 0.0;      // one-way delay, per FlowMonitor semantics
    double totalJitterSum = 0.0;
    uint64_t totalRttCount = 0;
    uint64_t totalRxBytes = 0;
    uint64_t totalTxPackets = 0;
    uint64_t totalRxPackets = 0;
    uint64_t totalLostPackets = 0;

    for (auto const& [fid, fstats] : stats)
    {
        if (fstats.rxPackets > 0)
        {
            totalDelaySum += fstats.delaySum.GetSeconds() * 1000.0;   // ms, one-way
            totalJitterSum += fstats.jitterSum.GetSeconds() * 1000.0; // ms
            totalRttCount += fstats.rxPackets;
            totalRxBytes += fstats.rxBytes;
        }
        totalTxPackets += fstats.txPackets;
        totalRxPackets += fstats.rxPackets;
        totalLostPackets += fstats.lostPackets;
    }

    // Throughput: total received bytes across all flows, divided by the
    // fixed application-active window (source start to source stop), not
    // a per-flow first/last-packet window, which is unstable for short flows.
    double appActiveDuration = (simTime - 0.5) - 1.0;  // matches sourceApps Start/Stop above
    double throughputMbps = (appActiveDuration > 0)
        ? (totalRxBytes * 8.0 / appActiveDuration) / 1e6
        : -1.0;

    // FlowMonitor's delaySum is END-TO-END (one-way) delay, not round-trip time.
    // We report both the directly measured one-way delay and a naive symmetric-path
    // RTT approximation (2x one-way), and label each explicitly rather than
    // conflating them -- this addresses the reviewer's point that latency
    // terminology must not be used interchangeably.
    double meanOneWayDelayMs = (totalRttCount > 0) ? (totalDelaySum / totalRttCount) : -1.0;
    double approxRttMs = (meanOneWayDelayMs >= 0) ? (2.0 * meanOneWayDelayMs) : -1.0;
    double meanJitterMs = (totalRttCount > 0) ? (totalJitterSum / totalRttCount) : -1.0;
    double pdr = (totalTxPackets > 0) ? (100.0 * totalRxPackets / totalTxPackets) : 0.0;

    std::cout << "===RESULT===" << std::endl;
    std::cout << "TcpVariant," << tcpVariant << std::endl;
    std::cout << "MeanOneWayDelay_ms," << meanOneWayDelayMs << std::endl;
    std::cout << "ApproxRTT_ms_2x_oneway," << approxRttMs << std::endl;
    std::cout << "MeanJitter_ms," << meanJitterMs << std::endl;
    std::cout << "Throughput_Mbps," << throughputMbps << std::endl;
    std::cout << "PDR_pct," << pdr << std::endl;
    std::cout << "TxPackets," << totalTxPackets << std::endl;
    std::cout << "RxPackets," << totalRxPackets << std::endl;
    std::cout << "LostPackets," << totalLostPackets << std::endl;
    std::cout << "AppActiveDuration_s," << appActiveDuration << std::endl;
    std::cout << "===END===" << std::endl;

    Simulator::Destroy();
    return 0;
}
