# NeuroCongest — Execution Files and Output

This repository contains every piece of code actually executed for the
NeuroCongest paper, along with the real terminal output each one
produced, captured as both raw text/CSV and screenshot images.

## Honest scope statement — read this first

This repository contains **two different kinds of result**, and they
must not be confused with each other:

| Folder | What it is | Real execution? |
|---|---|---|
| `ns3_simulation/` | Real NS-3 3.46 + 5G-LENA (NR module v4.1.1) packet-level simulation | **Yes** — one configuration (TCP NewReno, single macro gNB, 4 UEs, 3 s) |
| `monte_carlo_code/` | Python/NumPy/SciPy code assigning per-protocol summary statistics and drawing random samples | Yes, the *code* runs for real — but the underlying per-protocol numbers are author-assigned, not measured from network execution |

The Monte Carlo code's statistical machinery (random sampling, Wilcoxon
tests) genuinely executes and is reproducible — running it twice gives
identical output. What it does **not** do is simulate TCP congestion
control dynamics; it draws samples around numbers the authors chose.
The NS-3 folder is the only place in this repository where packets
actually flowed through a simulated network.

## Repository structure

```
.
├── README.md                          (this file)
├── ns3_simulation/
│   ├── neurocongest-baseline.cc       (real NS-3 + 5G-LENA simulation source)
│   └── ns3_run_output.txt             (real captured terminal output)
├── monte_carlo_code/
│   ├── run_simulation.py              (Monte Carlo model, Table 4 + significance)
│   └── real_timing_benchmark.py       (real executed timing, x86, not ARM)
├── data/
│   ├── table4_overall_performance.csv
│   └── table12_wilcoxon_significance.csv
├── figures/                           (regenerable charts, see gen_figures.py)
└── screenshots/
    ├── 01_ns3_real_execution.png      (terminal screenshot, real NS-3 run)
    ├── 02_monte_carlo_execution.png   (terminal screenshot, Monte Carlo run)
    └── 03_timing_benchmark_execution.png (terminal screenshot, real timing run)
```

## How to reproduce

### NS-3 packet-level simulation (real)

Requires NS-3 3.46 with the 5G-LENA NR module (v4.1.1) built as a
contrib module. Place `neurocongest-baseline.cc` in
`contrib/nr/examples/`, register it in that directory's `CMakeLists.txt`,
build with `./ns3 build`, then run:

```bash
./build/contrib/nr/examples/ns3.46-neurocongest-baseline \
    --tcpVariant=ns3::TcpNewReno --ueNum=4 --simTime=3.0
```

Expected output matches `ns3_simulation/ns3_run_output.txt` exactly
(deterministic given the same NS-3/NR version).

### Monte Carlo code (real code, assumed input parameters)

```bash
pip install numpy scipy pandas
cd monte_carlo_code
python3 run_simulation.py
python3 real_timing_benchmark.py
```

Both scripts use fixed random seeds and will reproduce identical output
(except `real_timing_benchmark.py`'s absolute timing numbers, which
depend on the CPU running it — only the hardware info line will differ
if run on different hardware).

## Why both kinds of result are included

The NS-3 result is the one piece of real packet-level evidence in the
paper; the Monte Carlo code is what generated every other reported
number. Both are included, both are labeled honestly, and the
screenshots exist specifically so a reader can see the real terminal
output rather than take the CSV values on trust.
